
<!DOCTYPE html>
<html lang="en">
<head>
	<title>FAQ-Jec_Kaarwaa.N </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="header.css">
  <link rel="stylesheet" type="text/css" href="FAQ.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

</head>

<body>
<?php require('../header.php') ;?>

<br>

<!-- Content -->

  <h3 align="center">Frequently Asked Questions</h3>
<div class="container-fluid faq_content" style="max-width:760px;padding-top: 20px;">

    <button class="collapsible">1. How can Kaarwaa.N provide me a platform for social service ?</button>
    <div class="content">
    <p>Kaarwaa.N tries to prepare students for Navodaya/gyanodaya exam and organize various events. You can join with us to make a better society.</p>
</div>

    <button class="collapsible">2. How can Kaarwaa.N help me to enhance my personality ? </button>
    <div class="content">
    <p>The yearlong schedule of Karwaa.N  provides various exciting experiences and opportunities . The experiences of teaching students , nukkad natak , plantation and other big events overall helps a student to improve their leadership , interpersonal , communication and planning skills . So it can really be helpful for any student.</p>
</div>

    <button class="collapsible">3. Will Kaarwaa.N affect my studies ? </button>
    <div class="content">
    <p>No , not at all this is only a myth in contrast meaning of our Alumini who joined Karwaa.N are today at very good positions .  Believe me Karwaa.N will never affect your studies , on the other hand it will groom you and will make you a better personality. </p>
</div>

    <button class="collapsible">4. What are the recent success of Kaarwaa.N ?</button>
    <div class="content">
    <p>Karwaa.N had set Many milestone in its short lifespan . We had established a Karwaa.N park in the college itself and have also given results in the Navodaya/gyanodaya examination.</p>
</div>

    <button class="collapsible">5. Is there any annual fees/registration fees for becoming member of Kaarwaa.N ?</button>
    <div class="content">
    <p>Karwaa.N is a non proffitable organization and there is no fees for becoming a member of 
    Kaarwaa.N .</p>
</div>

    <button class="collapsible">6. What are the big events conducted by Kaarwaa.N ?  </button>
    <div class="content">
    <p>Karwaa.N organizes various events such as plantation , cleanliness drive , nukad-natak clothe distribution , orphanage visit and overall year-long student program for preparation of 'Navodaya'  examination .</p>
</div>
</div>
</div><br>
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}
</script>

  <!--Footer-->

<?php require('../footer.php') ;?>


 <!-- Open when someone clicks on the span element  -->
 <script type="text/javascript">
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

/* Close when someone clicks on the "x" symbol inside the overlay */
function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}
</script>


<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	


  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  
 
}
	
 
 

</style>
     
 <script>
    
</script>    



</body>
</html>
