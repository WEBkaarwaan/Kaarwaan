<?php
session_start();
if(isset($_SESSION['uname'])){
  echo "<script>location.href='welcome.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kaarwaa.N- Member Login </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="member_login.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
   
</head>

<body>
<?php require('../header.php') ;?>
 <br>




   <!-- Login Form  -->

    <div class="container donation_form_container" style="max-width: 450px;">
         <form action="" method="POST">
            <div class="container-fluid inside_form_container">
                <h3><strong>Members Regitration</strong></h3>
                <hr>
                <h6 style="font-size: 12px;"><i>Note:(If you are an active Kaarwaa.N member and not registered yet, please go to <a href="" style="color: blue;">Member Registration</a>).</i></h6>
                <hr>
                <label for="mbr_uname"><b>User Name :</b></label>
                <input type="email" id="mbr_uname" name="mbr_uname"  placeholder="Your email id" required><br>

                
                    <label for="mbr_upass"><b>Password :</b></label>
                    <input  type="password" id="mbr_upass" name="mbr_upass" placeholder="Enter Password" required>
                

                <div class="clearfix">
            
                    <button  type="submit" name="mlogin_submit" class="donatebtn" >Login</button>
                </div>
          </div>     
      </form>
</div>

<br>
<?php

if(isset($_POST) && array_key_exists('mlogin_submit',$_POST) )
        {


           

             /////code to stop login anyone
          ?>
          <script type="text/javascript">alert('Sorry! Service Unavailbale.')</script>
<?php
          exit();


  $uname = $_POST['mbr_uname'];
  $pwd = $_POST['mbr_upass'];


 
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');

$sql = "SELECT * FROM join_us_member where mbr_email = '$uname' ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  if($pwd == $row['mbr_pass']){
    $_SESSION['uname']=$row['mbr_name'];
    $_SESSION['clg']=$row['mbr_clg'];

    echo "<script>location.href='welcome.php'</script>";
  }else{
    echo "<script>alert('Incorrect Password')</script>";
  }
  } else {
    echo "<script>alert('Username Does Not Exist')</script>";
}
}
?>
  <!--Footer-->


<!--Footer-->


<?php require('../footer.php') ;?>





<style>
	
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	


  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  

 

 
}
	@media only screen  and (min-width : 768px) {
		
		
 



}


 

</style>
     
 <script>



</script>    



</body>
</html>
