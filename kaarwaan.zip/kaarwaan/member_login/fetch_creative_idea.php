<?php
session_start();

if (isset($_SESSION['uname'])) {
  echo "<h1>Welcome to crative view</h1>";
  
  
  echo "<br><a href='welcome.php'><input type='button' value='back' name='back'</a>";
  echo "<br> ";
}
else
{
    echo "<script>location.href='login.php'</script>";
  }

?>
