<?php
session_start();
if(!isset($_SESSION['uname'])){
  echo "<script>location.href='member login.php'</script>";
}
?>
<!DOCTYPE html>

<html lang="en">
<head>
  <title>Kaarwaa.N- Member Login </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" type="text/css" href="member_login.css">

  <!--Bootstrap-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
   
</head>

<body>

<?php require('../header.php') ;?>
<br>

<div class="container-fluid"  style="background-color: lightgreen;padding:6px;  ">
   <div class="row">
   <div class="container-fluid col-sm-4" style="margin: auto;" ><h5>Welcome back! <i style="color: tomato;"><?php echo " " .$_SESSION['uname'].""?></i></h5></div>
    <div class="col-sm-8" align="right"><a href="logout.php"><button style="min-width: 100px; border-radius: 8px;color:white;background-color: red;padding: 4px;box-shadow: 0px 0px 0px 3px tomato; border: none; ">Logout</button></a></div>
    </div>
</div>  
<br>

<div class="container-fluid" align="center" style="max-width: 8000px;">
    <h4>Choose Option :</h4>
    <hr style="max-width: 600px;">
</div>


<div class="container-fluid">
    <div class="row">

        <div class="container-fluid col-sm-2">
            <div class="option_circle" style="border-radius: 360px; border: 1px solid gray;">
                <p>Creative Ideas :</p>
              
            </div>
        </div>

        <div class="container-fluid col-sm-2">
            <div class="option_circle" style="border-radius: 360px; border: 1px solid blue;">
                <p>Creative Ideas :</p>              
            </div>
        </div>    

        <div class="container-fluid col-sm-2">
            <div class="option_circle" style="border-radius: 360px; border: 1px solid red;">
                <p>Creative Ideas :</p>                                      
                                            
            </div>    
        </div>

    </div>
</div>

        
  <!--Footer-->

<!--Footer-->
<?php require('../footer.php') ;?>





<style>
  
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) { 
  
  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
 
 
}
  @media only screen  and (min-width : 768px) {
    
    
 



}


 

</style>
     
 <script>



</script>    



</body>
</html>
