
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Privacy Policy</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	
  

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

   
</head>

<body>

<?php require('../header.php') ;?>
<br>

<!-- Content -->
<div class="container fluid col-sm-10">

    <div class="journey_content" style="max-width: 1200px;">
      <h3 align="center">Privacy Policies</h3>
      <hr style="max-width: 700px;">
    <h4>Information Gathering :-</h4>
<ol>
<li>Kaarwaa.N collects information from the users in a number of ways, for example when the user:<br>

      <ul>
        <li>Makes a donation</li>
        <li>Signs up for a member and volunteer login</li>
        <li>Submit Creative ideas and feedbacks</li>

      </ul>

<li>While forwarding a donation for Kaarwaa.N the well-wishers have to submit some personal information as it would help us ensuring genuine contributions:
<ul>
<li>Your name
<li>Your email and mailing address
<li>Your contact number
<li>Your payment processing details
<li>Any other data as required
</ul>
<li>Kaarwaa.N does not collect or record the user’s personal information unless he/she chooses to provide it.</ol>

<h4>Use of Personal Information :-</h4>
<ol>
<li>General browsing of  Kaarwaa.N  website is anonymous and it does not register the user's personal information except the time, date and place of visits and the name of internet service provider. This data is used only for statistics and diagnosis.

<li>By signing up for various services offered by Kaarwaa.N the user explicitly authorizes us to collect information based on the user’s usage. The information is used to help provide a better experience to the user and is used as per the user’s specified instructions.

<li>Kaarwaa.N keeps the user information strictly confidential and this information is secured safely. All relevant information collected through website is handled and used by internal and authorized officials only. It is never shared with any external agencies or third party individuals.

<li>Kaarwaa.N uses the information given to it in the following ways:

<ul><li>To keep an accurate record of all the donations received

<li>To update users about its happenings and developments through bulletins and newsletters, with an option of not to subscribe for the same

<li>To make sure the user is receiving the most appropriate and relevant information

<li>To find out more about the people who are visiting the Kaarwaan.N website, donating, or joining its program.</li></ul>

<li>Usually, Kaarwaa.N does not store user data. In case of specific sign-ups, the data is stored as per user request. The user can opt to delete all the information he/she has provided by simply requesting such by mail. All information, without exception, will be deleted in two working days.</li></ol><br>

<h4>Privacy of e-mail lists :-</h4>
<ul>
<li>Individuals who join Smile Foundation’s mailing lists via its website or through its campaigning engagements are added to its email database. Kaarwaa.N does not sell, rent, loan, trade, or lease the addresses on our lists to anyone.</ul><br>

<h4>Payment Gateway :-</h4>
<ol>
<li>Kaarwaa.N uses well-recognised and proven technology for payments. Payment information is transferred by the use of an SSL connection which offers the highest degree of security that the donor’s browser is able to support.</li>

<li>Several layers of built-in security, including an advanced firewall system, encryption of credit card numbers, and use of passwords, protect the collected information.</li></ol><br>

<h4>External Web Services :-</h4>
<ol>
<li>Kaarwaa.N uses a number of external web services on its site to display content within its web pages. For example, to display video it uses YouTube. As with the social media buttons, Smile Foundation cannot prevent these sites, or external domains, from collecting information on the user’s consumption of the content embedded on its site.</li>

<li>The Kaarwaa.N website contains links to other websites for the benefit of its visitors. This Privacy Policy does not apply to such other websites.</li>

<li>Kaarwaa.N is not expressly or impliedly responsible for, or liable to any loss or damage caused to a user by the collection, use and retention of Personal Information by such website in any manner whatsoever. It is important that the users review the privacy policies of all websites they visit before disclosing any information to such websites.</li></ol><br>


<h4>Refund and Cancellation Policy :-</h4>
<ul>
 <li>We make public our policy on refund and cancellation of donations received for the social cause on payment gateway as under:-</li>

<li>No refund/cancellation for the donated amount by any donor will not be entertained, the online donations through the online payment gateway.</li>

<li>No cash or refund of money will be allowed.</li>

<li>Once received the donation for a cause will not be refunded to the donor. No cancellation to be made. The donation will be used for the children education and other social welfare activities.</li>
<br>
Jabalpur Engineering College , Gokulpur<br>
Jabalpur (M.P.) - 482011<br>
Phone : +91-7617319811

    </div><br>
    </div>
  </div>

  <!--Footer-->

<?php require('../footer.php') ;?>




 

<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
 

  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
}

 

</style>
     
 <script>
    
</script>    



</body>
</html>
