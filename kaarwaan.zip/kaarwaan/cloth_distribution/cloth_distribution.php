<!DOCTYPE html>
<html lang="en">
<head>

	<title>Kaarwaa.N-Cloth Distribution </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="header.css">
  <link rel="stylesheet" type="text/css" href="cloth_distribution.css">

	<!--Bootstrap-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

 
   
</head>

<body>

<?php require('../header.php') ;?>


<!-- Carosel -->
 <div class="about_right_col" style="">
          <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators" >
              <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                  
            </ul>
            <div class="carousel-inner" >
              <div class="carousel-item active cloth_img_carousel_dimension">
                <img src="img/cloth_head_1.jpg" alt="Los Angeles">
                <div class="carousel-caption">
<!--                   <h3> plantation </h3>
                  <p>We had such a great time in Plantation</p> -->
                </div>   
              </div>

          <div class="carousel-item cloth_img_carousel_dimension">
            <img src="img/cloth_head_2.jpg" alt="Chicago" >
            <div class="carousel-caption">
         <!--    <h3>Plantation</h3>
            <p>We had such a great time in Plantation</p> -->
            </div>   
          </div>

        
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
        </a>
      </div>
</div><br>

<!-- Cloth Content -->

      <div class="container-fluid">
        <div class="container-fluid ">
          <h4 align="center"><b>Cloth Distribution</b></h4>
        </div><hr style="max-width: 400px;">
          <div class="container-fluid cloth_content" align="center">
          
          
            <p>Kaarwaa.N regularly organises cloth distrubution programme for needy. Most of the clothes collected from the households in our contact, we also volunteer for those who wants to donate their clothes. Anyone can donate their clothes to help poor.</p>
          <hr style="max-width: 1200px">
        </div><br>

<!-- Scenario -->

<div class=" container-fluid cloth_success" style="margin: auto;max-width: 1200px;">
  <h3> <strong><u>Current Scenario</u> :</strong></h3>
  <div class="row">
    <div class="success_photo col-sm-4" style="max-width: 400px; margin: auto;"> <img style="border-radius: 4px;" src="img/cloth_scenerio.jpg" alt="cloth Photo"> </div>
    <div class="success_content col-sm-8">
      <p>The moment you stop your car at the traffic red light, you see a dirty looking woman with a child in her arm come running to you or a little boy with running nose banging your car window or a handicapped old man asking for alms. This is a common sight in India. <br><br>According to a recent Indian government committee constituted to estimate poverty, nearly 38% of India’s population (380 million) is poor.Even after more than 50 years of Independence India still has the world's largest number of poor people in a single country.<br><br>
       A strong system of incentives and disincentives also needs to be introduced. The encouragement of non-governmental organizations and private sector individuals in tackling poverty is imperative, as the state cannot do everything.<br><br>
      <strong>kaarwaa.N always try and takes steps against poverty.</strong></p>
    </div>
 </div>
</div>
<br>

<!-- Step taken by Kaarwaa.N  -->

      

<!-- Photos in Card-->

        <div class="card-deck container-fluid"style="max-width: 1200px;margin: auto; padding: 10px ; border: 2px solid lightgrey;">
<!-- Card 1  -->
          <div class="card" style="max-width:400px">
            <img class="card-img-top" src="img/cloth_card_1.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">You might have resources but not everyone.</p>
            </div>
          </div>
<!-- Card 2 -->
           <div class="card" style="max-width:400px">
             <img class="card-img-top" src="img/cloth_card_2.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Happiness results from what we give.</p>
            </div>
          </div>
<!-- Card 3 -->
          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/cloth_card_3.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Joy multiplies when it is shared. </p>
            </div> 
          </div>
<!-- Card 4 -->
          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/cloth_card_4.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Think of giving not as a duty but as a privilege.</p>
            </div>
          </div>

      </div> 
    <br>


  <!--Footer-->

<?php require('../footer.php') ;?>




<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
 

  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  

</style>
     
 <script>
    
</script>    



</body>
</html>
