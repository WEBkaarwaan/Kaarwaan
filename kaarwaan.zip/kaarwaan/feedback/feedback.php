
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kaarwaa.N- join as a Volunteer </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="feedback.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

   
</head>

<body>
<?php require('../header.php') ;?>
 <br>

   <!-- Member registration(join us)  -->
 

  


   
   <div class="container donation_form_container" style="max-width: 450px;">
         <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" >
            <div class="container-fluid inside_form_container">
                <h4><strong>Feedback to Developers</strong></h4>
                <hr>
                <label for="f_name"><b>Name :</b></label>
                <input type="text" name="f_name"  placeholder="Your Full Name" required><br>
                 
                <label for="f_email"><b>Email :</b></label>
                <input type="text" name="f_email"  placeholder="Your Email" required><br>

                <label for="f_feedback"><b>Feedback :</b></label>
                <textarea name="f_feedback"  placeholder="Write here..." required></textarea><br>
                

                <div class="clearfix">
            
                    <button  type="submit" name="f_submit" class="donatebtn" >Submit</button>
                </div>
          </div>     
      </form>
</div>

   
    

   
<br>

  <!--Footer-->


<?php require('../footer.php') ;?>






<style>
	
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
 

  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  
 
 

 
}
	@media only screen  and (min-width : 768px) {
		
		
 



}


</style>
     
   
<?php 



if(isset($_REQUEST['f_submit'])){


   
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');
  

$sql = "INSERT INTO feedback (f_sn, f_name, f_email, f_feedback) 
          VALUES (NULL, '".$_POST["f_name"]."', '".$_POST["f_email"]."', '".$_POST["f_feedback"]."')";


if ($conn->query($sql) === TRUE) {
    // echo "Your have Submit yourself.";
     ?>

  
    <script type="text/javascript"> 
      alert('Thankyou! Your Feedback has been submitted');
      location.href = "feedback.php";

  </script> 


<!-- </div> -->
<?php
   
   

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  

}
}
 
?>    


</body>
</html>
