

        <!--   ///***********This Is header common to all pages with css***** -->
                    <!-- (this doesnt inclue bootsrap library) -->
<div class="head_main_div">
  <div class="inside_head_div">
    	<div class="Kaarwaan_logo"><img src="/img/logo.png"> </div>
    	   <!--this div will hide, screen below 768 with meadia query-->
    	<div class="div_hide"><h6><strong>-A Step For The Welfare Of Another India</strong><h6></div>
   </div> 	
</div>

<!--nav bar-->

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top kaarwaan_navbar">
        <a class="navbar-brand" href="/index.php">Home</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=" #collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
        </button>
 <div class="collapse navbar-collapse" id="collapsibleNavbar">
  <ul class="navbar-nav" >
     <!-- Dropdown -->
    <li class="nav-item dropdown Kaarwaan_dropdown">
      <a class="nav-link dropdown-toggle" style="" href="" id="navbardrop" data-toggle="dropdown">
        About Us
      </a>
      <div class="dropdown-menu" >
        <a class="dropdown-item" href="/journey/journey.php">Journey</a>
        <a class="dropdown-item" href="/aim_vision/aim_vision.php">Aim & Vision</a>
        <a class="dropdown-item" href="/team_alumini/team_alumini.php">Team & Alumini</a>
        <a class="dropdown-item" href="/buy_tshirt/buy_tshirt.php">Buy T-Shirt</a>
        
      </div>
    </li>  

   <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href=""  id="navbardrop" data-toggle="dropdown">
        Our Work
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/child_education/child_education.php">Child Education</a>
        <a class="dropdown-item" href="/orphanage/orphanage.php">Orphanage Visit</a>
        <a class="dropdown-item" href="/plantation/plantation.php">Plantation</a>
        <a class="dropdown-item" href="/cloth_distibution/cloth_distibution.php">Cloth Distribution</a>
       
        
      </div>
    </li>    
    
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="/" id="navbardrop" data-toggle="dropdown">
        Donate
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/financial_help/financial_help.php">Financial Help</a>
        <a class="dropdown-item" href="/blood_donation/blood_donation.php">Blood Donation</a>
        <a class="dropdown-item" href="/education_kit/education_kit.php">Educational Kit</a>
        <a class="dropdown-item" href="/cloth_donation/cloth_donation.php">Cloth Donation</a>
      </div>
    </li>

     <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Events
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/events/events.php">All Events</a>
      </div>
    </li>

    

    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Join Us
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/join_volunteer/join_volunteer.php">As a volunteer</a>
        <a class="dropdown-item" href="/join_volunteer/join_volunteer.php">As a Member</a>
       
        
      </div>
    </li>

      
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="/member_login/member_login.php" id="navbardrop" data-toggle="dropdown">
        Login
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/member_login/member_login.php">Member Login</a>
        <a class="dropdown-item" href="/admin_login/admin_login.php">Admin Login</a>        
    </div>
	  </li>

  </ul>
</div>  
</nav>



       


<style type="text/css">
  


html { 
      font-size: calc(.9em + 0.4vw) 
      
      }
html a 
  { 
    color: black;

  }
  html a:hover 
  { 
    color: darkgreen;
    
  }

  .head_main_div
  {    
      width: 100%; height: 120px;padding-top: 10px;
    /*   gradient code*/
    background: rgb(191,210,85); /* Old browsers */
    background: -moz-linear-gradient(-45deg,  rgba(191,210,85,1) 0%, rgba(142,185,42,1) 37%, rgba(121,175,100,1) 50%, rgba(121,175,100,1) 50%, rgba(239,152,64,1) 60%); /* FF3.6-15 */
    background: -webkit-linear-gradient(-45deg,  rgba(191,210,85,1) 0%,rgba(142,185,42,1) 37%,rgba(121,175,100,1) 50%,rgba(121,175,100,1) 50%,rgba(239,152,64,1) 60%); /* Chrome10-25,Safari5.1-6 */
    background: linear-gradient(135deg,  rgba(191,210,85,1) 0%,rgba(142,185,42,1) 37%,rgba(121,175,100,1) 50%,rgba(121,175,100,1) 50%,rgba(239,152,64,1) 60%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#bfd255', endColorstr='#ef9840',GradientType=1 );
  }


.inside_head_div
{ 
  width: 100%;
  height: 70px;
  
}

.Kaarwaan_logo
{ 
  float: left; 
  
}
.div_hide
{ 
  float: right; 
  margin-top: 15px; 
  width: 32%;
  margin-right: 10px;
  max-width: 32%;
  margin-top:65px;  

}
.div_hide h6
{
  font-size: 1.4vw;
}
.kaarwaan_navbar
{ 
  

  padding: 0px;

}

.navbar-nav li a:hover {
  background-color: #436C23;
}
.dropdown-menu a:hover
{
  

}
.dropdown:hover .dropdown-menu
{
  display: block;
}



 /*media query if screen size less than 576*/

  @media only screen and (max-width: 575px) { 
 

  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
  
  .div_hide {
    display: none;
  }
  .Kaarwaan_logo img
  { 
  width: 100%;
  height: 60px; 
  }  

  .head_main_div
  {
    width: 100%; height: 80px;padding-top: 6px;
  }
 
 
 
}

  /*media query if screen size greater than 768*/
  @media only screen  and (min-width : 768px) 
{
    
    

    
}


.kaarwaan_navbar
{
  padding-top: 0px;
  padding-bottom: 0px; 
  font-size: inherit;  


}


</style>