
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kaarwaa.N-Team And Alumini </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="team_alumini.css">


	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

    <!--Bootstrap Swiper-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"></script>
   
</head>

<body>


<!--nav bar-->

<?php require('../header.php') ;?>

<?php  //Events fetch from database
 

   
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');
   
$sql = "SELECT mbr_name, mbr_image, mbr_batch, mbr_post FROM join_us_member WHERE mbr_batch='2021' "  ;

$result = $conn->query($sql);

?>



       <!-- Swiper -->
<div class="container-fluid mentor_swiper_div">
  <h3 ><strong>Batch 2017-21</strong></h3>
  <div class="swiper-container mentor_swiper_container">
    <div class="swiper-wrapper ">

      <?php
        if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) 
    {   
        $image_path = "";
        $image_path = $row['mbr_image'];
        ;
        $image_path = "/join_member/mbr_photo/".$image_path ;
        
       
        
      ?>

       <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card"  >
         <?php echo '<img class="card-img-top" src="'.$image_path.'" alt="Card image" >' ?>
              
              
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title"><?php echo $row["mbr_name"]; ?></h6>
                <p class="card-text"><?php echo $row["mbr_post"]; ?></p>


              </div>
            </div>
      </div>
        <?php  }
}
      else {
    // echo "We are sorry, data is  unavailable";
      } 

?>
      
     
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</div>    
  <!--Swiper EnD-->    
  <br><br>










 <!-- Swiper -->
<div class="container-fluid mentor_swiper_div">
  <br><h3 ><strong>Batch 2016-20</strong></h3>
   <div class="swiper-container mentor_swiper_container" >
    <div class="swiper-wrapper ">
      <div class="swiper-slide mentor_swiper_slide">
              <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image088.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" style="padding: 0px 0px 0px 0px;">
                <h6 class="card-title">MR. RAHUL PATIDAR</h6>
                <p class="card-text">President</p>
              </div>
            </div>
    </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image098.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MISS. EKTA BARPETE</h6>
                <p class="card-text">Vice-President</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MR. HIMANSHU SHANKHLA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image090.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MR. NISHANT NAGWANSHI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image092.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MR. CHNACHAL SINGH THAKUR</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MR. RISHI MISHRA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image094.png" alt="Card image">
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MR. SHUBHAM MISHRA</h6>
                <p class="card-text">Some example text  architect and       Kaarwaa.N Member</p>

              </div>
            </div>        
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MR. NAVNEET</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MR. NEETIRAJ MALVIYA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
    
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image099.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MISS. POOJA SONI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image101.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MISS. SANGEETA PARASTE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image103.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MISS. AARTI DHURVE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. USHA SURYAWANSHI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MISS. SWATI SONI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MISS. ANSHUL  TRIPATHI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image111.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title" >MISS. SHRUTI SINGOUR</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. ANKIT ATHNERE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. SONAM</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. ARADHNA MISHRA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SHAILENDRA  NAMDEV</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. MANISHA PATEL</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. DEEPAK PATIDAR</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SONU BARIYA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. ASHUTOSH DUBEY</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SAKET KHARE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. AARYAN YADAV</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. DAMINI RAJAK</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. HIMANSHU GUPTA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
     
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</div>    
  <!--Swiper EnD-->      
<br><br>


 <!-- Swiper -->
<div class="container-fluid mentor_swiper_div">
  <h3 ><strong>Batch 2015-19</strong></h3>
  <div class="swiper-container mentor_swiper_container">
    <div class="swiper-wrapper ">
      <div class="swiper-slide mentor_swiper_slide">
              <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image068.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MR. NEERAJ PATIDAR</h6>
                <p class="card-text">President</p>
              </div>
            </div>
    </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image070.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MISS. RAJNI PENDRO</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. SHUBHANGI SINGH</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MISS. JAGRITI MOURYA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image076.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. RITIKA WATTE</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image077.png" alt="Card image">
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MISS. AYUSHI KHATIK</h6>
                <p class="card-text"> Kaarwaa.N Member</p>

              </div>
            </div>        
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image078.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISSS. YUKTA PANDEY</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SHANU SINGH</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. SMRITI CHAURASIA</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image081.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SANKALP GARG</h6>
                <p class="card-text"><Br>Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SAURABH SINGH  RAJPOOT</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SUDEEP KUMAR</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image084.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. ASHUTOSH MISHRA</h6>
                <p class="card-text">Treasurer</p>
              </div>
            </div>
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image085.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. TOHIT KHAN</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. ABHISHEK AGRAWAL</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. SHWETA MACHIWAR</h6>
                <p class="card-text">Kaarwaa.N Member </p>
              </div>
            </div>
      </div>
      
     
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</div>    
  <!--Swiper EnD-->      
<br><br>
   
   <!-- Swiper -->
<div class="container-fluid mentor_swiper_div">
  <h3 ><strong>Batch 2014-18</strong></h3>
  <div class="swiper-container mentor_swiper_container">
    <div class="swiper-wrapper ">
      

        <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image061.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. SHIKHAR BARVE</h6>
                <p class="card-text">President</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
              <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image059.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MISS. AYUSHI JAIN</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
    </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MISS. PRAGYA AGRAWAL</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      
    
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SHIVANI MISHRA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image062.png" alt="Card image">
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. UMESH PATIDAR</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>        
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image063.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SHARAD KANT NAGAICH</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. KARAN KUMAR PRAJAPATI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      
     
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</div>    
  <!--Swiper EnD-->       
<br><br>

 <!-- Swiper -->
<div class="container-fluid mentor_swiper_div">
  <h3 ><strong>Batch 2013-17</strong></h3>
  <div class="swiper-container mentor_swiper_container">
    <div class="swiper-wrapper ">
      <div class="swiper-slide mentor_swiper_slide">
              <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MR. ANOOP SHARMA</h6>
                <p class="card-text">President</p>
              </div>
            </div>
    </div>
     <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image047.png" alt="Card image">
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. ASHISH BHARADWAJ</h6>
                <p class="card-text">Vice President </p>

              </div>
            </div>        
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. SHUBHAM JAIN</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image042.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. TAJASVI SAXENA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. ANAND AROLE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image045.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. AMIT YADAV</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
     
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. DIVYANSH JAIN</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image049.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SAURABH JAIN</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image051.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. ANCHAL TIWARI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. DIVYA PAROHA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image054.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. SHWETA MARKAM </h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. SHWETA SINGH</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image056.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. TRIPTI RATRE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS.SHUBHANGI SONI</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
     
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</div>    
  <!--Swiper EnD-->      
<br><br>
   <!-- Swiper -->
<div class="container-fluid mentor_swiper_div">
  <h3 ><strong>Batch 2012-16</strong></h3>
  <div class="swiper-container mentor_swiper_container">
    <div class="swiper-wrapper ">
      <div class="swiper-slide mentor_swiper_slide">
              <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image023.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MR. SANDEEP MEHTA</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
    </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MISS. SAKSHI PANDEY</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS. VARSHA Manglani</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MISS. NIMISHA PRASHANT</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image027.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MISS.KINJAL JAIN</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/user.png" alt="Card image">
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MISSS. PARIDHI GIRIYA</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>        
      </div>
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image030.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SATYA PRAKASH BISARIYA</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image031.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. RISHAB KHAMPARIYA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. YOGENDRA PRAJAPATI</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image035.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. MAYANK NEMA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image036.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. VIKRANT PANDEY</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image034.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. RAHUL JHA</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image039.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. SAMPDA SARAF</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
     
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</div>    
  <!--Swiper EnD--> 
<br><br>
        <!-- Swiper -->
<div class="container-fluid mentor_swiper_div">
  <h3 ><strong>Batch 2011-15</strong></h3>
  <div class="swiper-container mentor_swiper_container">
    <div class="swiper-wrapper ">

       <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image007.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. SAURAV KUMAR DEV</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>

      <div class="swiper-slide mentor_swiper_slide">
              <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image005.png" alt="Card image" >
              <div class="card-body swiper_inside_body swiper_inside_body" >
                <h6 class="card-title">MR. GAURAV PATIL</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
    </div>
     
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/image009.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. JITENDRA KUMAR TAMIYA</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. DEVENDRA MARKAM</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. HIMANSHU ZHARBADE</h6>
                <p class="card-text"> Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card">
              <img class="card-img-top" src="img/images_files/Surendra Emne.png" alt="Card image">
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title">MR. SURENDRA EMNE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>        
      </div>
      
      
      
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. RAJKUMAR MARSKOLE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image017.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. AVINASH GUPTA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
     
      <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/images_files/image019.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. KAMAL NATH DHURVE</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
       
        <div class="swiper-slide  mentor_swiper_slide">
             <!--Card of Mentor-->
            <div class="card swiper_card" >
              <img class="card-img-top" src="img/user.png" alt="Card image" >
              <div class="card-body swiper_inside_body" >
                <h6 class="card-title" >MR. ANURAG MISHRA</h6>
                <p class="card-text">Kaarwaa.N Member</p>
              </div>
            </div>
      </div>
     
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</div>    
  <!--Swiper EnD-->    
  <br><br>
     
 

<dir class="container-fluid sorry_note">
    <p >We are kindly sorry if your name is not listed aboove. Please registered yourself.</p>
</dir>

  <!--Footer-->

<?php require('../footer.php') ;?>






<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
    .swiper_card img
{
  
  height: 140px;
  width: 120px;
}
  
  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  
.swiper_inside_body
{
  padding: 0px 0px 0px 0px;
}
.mentor_swiper_container 
   {   
      
      height: 270px;
  }


 

</style>
     
 <script>
   /* swiper Slider*/
     var swiper = new Swiper('.swiper-container', {
      slidesPerView: 4,
      spaceBetween: 10,
      // init: false,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      breakpoints: {
        1024: {
          slidesPerView: 4,
          spaceBetween: 40,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 30,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        320: {
          slidesPerView: 1,
          spaceBetween: 10,
        }
      }
    });  
</script>    



</body>
</html>
