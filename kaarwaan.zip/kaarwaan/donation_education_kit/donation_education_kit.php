
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Donation - Educational Kit </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="donation_education_kit.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

   
</head>

<body>

<?php require('../header.php') ;?>
 <br>
 <div>
    
    <div class="container-fluid" style="margin: auto;height:100%;">
      <div class="row">

        <div class="col-sm-5 fdonation_box1 " style="">
          <div class="box1">
            <div class="container-fluid donation_quote" >
                
                <h4><b>Your Contribution will transform lives.</b></h4>
                <img  src="img/abc.jpg" >
                <br><br>
                <ul type="none" style="margin-left:0px; " >
                    
                    <li>Kaarwaa.N has taught more than thousand of children in India, since 2014.</li>
                    <li>Kaarwaa.N has organised more than hundereds of awareness programs.</li>
                    <li>We relies only on donations.</li>
                    <li></li>

                </ul>
             
                
             </div>                 
             
              </div>   

        </div> 





        <div class="col-sm-7 ">
<div class="container-fluid donation_form_container" style="width: 100%;">
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
          <div class="container-fluid inside_form_container">
            <h3 style="color:black;text-shadow:2px 1px darkseagreen;"><b>Donation - Education Kit for poor student</b></h3>
            <hr>
            <label for="ek_name"><b>Name :</b></label>
            <input type="text" name="ek_name"  placeholder="Enter Full Name" required><br>

            <label for="ek_contact"><b>Contact :</b></label>
            <input type="text"   name="ek_contact" placeholder="Enter Contact no." required>

            <label for="ek_email"><b>Email :</b></label>
            <input type="text" placeholder="Enter Email Id" name="ek_email" required>         

            <label for="ek_type"><b>Kit type : </b></label>
            <select name="ek_type">
                <option>Books and Copies</option>
                <option>School Bag</option>
                <option>School shoes</option>
                <option>Other</option>
            </select>

            <label>
            <input type="checkbox"  name="ek_alumini" style="margin-bottom:5px"> Are you Alumini of Jec ?
            </label><br>

            <label for="ek_write"><b>How will you send us the kit :</b></label>
            <br>
            <textarea name="ek_write" placeholder="Write here..." required></textarea>

           

    <p>After submiting, we will process your request and try to contact you for further process.</p>

    <div class="clearfix">
      
    <button type="submit" name="ek_submit" class="donatebtn" >Submit</button>
    </div>
  </div>
</form>
        
</div>
</div>
      <!--read carefully before donation-->
<dir class="container-fluid donation_info" style="width: 90%;">
      <h3>Read carefully before you donate : </h3>
      <ol type="1">
          <li>Kaarwaa.N is a non-profitable organisation, please we assured that your given education kit will be useful for poor students.</li>
          <li>Every year we prepare poor students for <strong>Jawahar Navodaya Vidyalaya</strong> so they can pursue their study from a prestigious school.</li>
          <li>You can write your purpose for donation.</li>
          <li>You will get an confirmation sms or email.</li>
          <li>You can also personally contact us before donation</li>
          <li>For any query, go to our FAQ section or contact us.</li>
          
      </ul>
 </dir>

 <dir class="container-fluid donation_quote">
    <p style="font-style: italic;color: red;">“You have not lived today until you have done something for someone who can never repay you." -John Bunyan</p>
 </dir>   
       
  <!--Footer-->

<?php require('../footer.php') ;?>






<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
 

  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  }

</style>
     
 <script>
    
</script>    



</body>
</html>


<?php  //form for educatio kit
 


if(isset($_REQUEST['ek_submit'])){
$ci_name = $ci_email = $ci_idea  = "";  
    
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');

  // check if Alumini or not
$cheked1 = "NO";

if( empty($_POST["ek_alumini"]) )
 { 
  // echo "not checked";
 $cheked1 = "NO";
  }
else {
  // echo "checked";
  $cheked1= "YES"; 
}





$sql = "INSERT INTO  education_kit (ek_sn, ek_name, ek_contact, ek_email, ek_type, ek_alumini, ek_write) VALUES (NULL, '".$_POST["ek_name"]."', '".$_POST["ek_contact"]."', '".$_POST["ek_email"]."', '".$_POST["ek_type"]."',  '".$cheked1."', '".$_POST["ek_write"]."')";


if ($conn->query($sql) === TRUE) {
    // echo "New record created successfully";
   ?>
     <script type="text/javascript">alert('You have registered successfully');</script>
     <script type="text/javascript">location.href = "donation_education_kit.php";</script>
  <?php

   

} else {
    // echo "Error: " . $sql . "<br>" . $conn->error;
}


}

?> 
