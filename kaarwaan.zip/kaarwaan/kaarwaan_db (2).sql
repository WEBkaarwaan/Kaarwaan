-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2020 at 09:51 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kaarwaan_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bd_registration`
--

CREATE TABLE `bd_registration` (
  `sn` int(11) NOT NULL,
  `bd_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bd_contact` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bd_email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bd_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bd_state` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bd_city` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bd_availability` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bd_registration`
--

INSERT INTO `bd_registration` (`sn`, `bd_name`, `bd_contact`, `bd_email`, `bd_type`, `bd_state`, `bd_city`, `bd_availability`) VALUES
(1, 'saurabh', '9898898424', 'jjsfkjha@gmail.com', 'A positive', 'Delhi', 'Delhi', 'available'),
(3, 'keshab', '9898898424', 'jjsfkjha@gmail.com', 'A positive', 'Delhi', 'Delhi', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `bd_request`
--

CREATE TABLE `bd_request` (
  `bdr_sn` smallint(6) NOT NULL,
  `bdr_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bdr_contact` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bdr_email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bdr_age` int(3) NOT NULL,
  `bdr_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bdr_date` date NOT NULL,
  `bdr_description` varchar(240) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bd_request`
--

INSERT INTO `bd_request` (`bdr_sn`, `bdr_name`, `bdr_contact`, `bdr_email`, `bdr_age`, `bdr_type`, `bdr_date`, `bdr_description`) VALUES
(1, 'sauravh', '7087780972', 'aura@gmail.com', 21, 'A POSITIVE', '2019-08-13', 'dbas fajhsfba fjas fa'),
(2, 'keshab', '08989889', 'ksehav@gmail.com', 21, '', '2018-04-03', 'KNDJAN');

-- --------------------------------------------------------

--
-- Table structure for table `certificate_verification`
--

CREATE TABLE `certificate_verification` (
  `cv_sn` int(11) NOT NULL,
  `cv_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cv_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cv_issued_date` date NOT NULL,
  `cv_post` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certificate_verification`
--

INSERT INTO `certificate_verification` (`cv_sn`, `cv_name`, `cv_id`, `cv_issued_date`, `cv_post`) VALUES
(1, 'Keshav', '242D32J4223', '2019-08-21', 'Treasurer');

-- --------------------------------------------------------

--
-- Table structure for table `cloth_donation`
--

CREATE TABLE `cloth_donation` (
  `cd_sn` int(11) NOT NULL,
  `cd_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cd_contact` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cd_email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cd_type` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cd_alumini` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cd_write` varchar(245) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cloth_donation`
--

INSERT INTO `cloth_donation` (`cd_sn`, `cd_name`, `cd_contact`, `cd_email`, `cd_type`, `cd_alumini`, `cd_write`) VALUES
(1, 'saurabh', '9575542946', 'about.srb@gmail.com', '', 'yes', 'jbjkf jkabf jkbfa jkbaf');

-- --------------------------------------------------------

--
-- Table structure for table `creative_view`
--

CREATE TABLE `creative_view` (
  `sn` int(11) NOT NULL,
  `ci_name` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ci_email` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ci_idea` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `creative_view`
--

INSERT INTO `creative_view` (`sn`, `ci_name`, `ci_email`, `ci_idea`) VALUES
(19, 'jitendran sharma', 'jitendraagre@gmail.com  ', '2`231`3`1 adjj jkjf  AD');

-- --------------------------------------------------------

--
-- Table structure for table `education_kit`
--

CREATE TABLE `education_kit` (
  `ek_sn` int(11) NOT NULL,
  `ek_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ek_contact` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ek_email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ek_type` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ek_alumini` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ek_write` varchar(245) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `education_kit`
--

INSERT INTO `education_kit` (`ek_sn`, `ek_name`, `ek_contact`, `ek_email`, `ek_type`, `ek_alumini`, `ek_write`) VALUES
(1, 'subh', '89787878897', 'subh@gmail.com', 'Books and Copie', 'YES', 'khj knjsa jnjkaf');

-- --------------------------------------------------------

--
-- Table structure for table `events_list`
--

CREATE TABLE `events_list` (
  `ev_sn` int(11) NOT NULL,
  `ev_date` date NOT NULL,
  `ev_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ev_location` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_sn` int(11) NOT NULL,
  `f_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f_email` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f_feedback` varchar(234) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_sn`, `f_name`, `f_email`, `f_feedback`) VALUES
(12, 'jitendra sharma', 'jitednra@gmail.com', 'great work. need to improve');

-- --------------------------------------------------------

--
-- Table structure for table `financial_donation`
--

CREATE TABLE `financial_donation` (
  `fd_sn` int(11) NOT NULL,
  `fd_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fd_contact` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fd_email` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fd_description` varchar(235) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fd_amount` int(10) NOT NULL,
  `fd_reference_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fd_status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `financial_donation`
--

INSERT INTO `financial_donation` (`fd_sn`, `fd_name`, `fd_contact`, `fd_email`, `fd_description`, `fd_amount`, `fd_reference_id`, `fd_status`) VALUES
(26, 'mohan', '9575542946', 'about.srb@gmail.com', 'as asdf', 100, 'a858ddf35ea4f853e360', 'failure'),
(32, 'hitesh', '9340281828', 'cont.hry@gmail.com', 'sda a f', 150, '2061ee0c1ef9a6a98260', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `join_us_member`
--

CREATE TABLE `join_us_member` (
  `mbr_sn` int(11) NOT NULL,
  `mbr_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_contact` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_clg` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_branch` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_post` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Kaarwaa.N Member',
  `mbr_blood` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_describe` varchar(245) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_pass` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_image` varchar(130) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mbr_batch` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `join_us_member`
--

INSERT INTO `join_us_member` (`mbr_sn`, `mbr_name`, `mbr_contact`, `mbr_email`, `mbr_clg`, `mbr_branch`, `mbr_post`, `mbr_blood`, `mbr_describe`, `mbr_pass`, `mbr_image`, `mbr_batch`) VALUES
(4, 'Yogendra Singh Rathore', '7617319811', 'y1998rathore@gmail.com', 'Jabalpur Engineering College', 'Industrial and Production Engi', 'President', 'Not Interested', '   dajfj', 'yogi@7617', 'Yogendra Singh Rathore_yogi121.jpg', 2021),
(9, 'Keshav Parihar', '8085127280', 'justparihar04@gmail.com', 'Jabalpur Engineering College', 'Information Technology Enginee', 'Treasurer', 'Not Interested', ' Oh yes  ', 'justparihar', 'Keshav Parihar_keshav_kaarwaan.jpg', 2021);

-- --------------------------------------------------------

--
-- Table structure for table `join_us_other`
--

CREATE TABLE `join_us_other` (
  `other_sn` int(11) NOT NULL,
  `other_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_contact` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_profession` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_state` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_city` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_blood` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_motive` varchar(245) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `join_us_other`
--

INSERT INTO `join_us_other` (`other_sn`, `other_name`, `other_contact`, `other_email`, `other_profession`, `other_state`, `other_city`, `other_blood`, `other_motive`) VALUES
(8, 'saurabh', '080-898-', 'djbajkdb@gmai.com', 'jhdjhsh', 'MP', 'Chhatarpur', 'A POSITIVE', 'jjk k f h asf k kfa');

-- --------------------------------------------------------

--
-- Table structure for table `join_us_student`
--

CREATE TABLE `join_us_student` (
  `std_sn` int(11) NOT NULL,
  `std_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_contact` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_clg` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_sem` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_blood` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_motive` varchar(245) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `join_us_student`
--

INSERT INTO `join_us_student` (`std_sn`, `std_name`, `std_contact`, `std_email`, `std_clg`, `std_sem`, `std_blood`, `std_motive`) VALUES
(1, 'keshav', '8989797979', 'keshabn@gmail.com', 'jabalpur engineering college', 'first sem', 'A positive', 'jasfa fajnasf afjkhaf ajkfa'),
(2, 'saura', '9809709097', 'jdajkb@gmai.com', 'Jabalpur Engineering College', 'First Semester', 'Not Interested', 'jndja hfah hhafb ha');

-- --------------------------------------------------------

--
-- Table structure for table `reference_id`
--

CREATE TABLE `reference_id` (
  `ri_sn` int(11) NOT NULL,
  `ri_otp` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reference_id`
--

INSERT INTO `reference_id` (`ri_sn`, `ri_otp`) VALUES
(1, 'js18h8hh8');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bd_registration`
--
ALTER TABLE `bd_registration`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `bd_request`
--
ALTER TABLE `bd_request`
  ADD PRIMARY KEY (`bdr_sn`);

--
-- Indexes for table `certificate_verification`
--
ALTER TABLE `certificate_verification`
  ADD PRIMARY KEY (`cv_sn`);

--
-- Indexes for table `cloth_donation`
--
ALTER TABLE `cloth_donation`
  ADD PRIMARY KEY (`cd_sn`);

--
-- Indexes for table `creative_view`
--
ALTER TABLE `creative_view`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `education_kit`
--
ALTER TABLE `education_kit`
  ADD PRIMARY KEY (`ek_sn`),
  ADD UNIQUE KEY `ek_email` (`ek_email`);

--
-- Indexes for table `events_list`
--
ALTER TABLE `events_list`
  ADD PRIMARY KEY (`ev_sn`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_sn`);

--
-- Indexes for table `financial_donation`
--
ALTER TABLE `financial_donation`
  ADD PRIMARY KEY (`fd_sn`),
  ADD UNIQUE KEY `fd_reference_id` (`fd_reference_id`);

--
-- Indexes for table `join_us_member`
--
ALTER TABLE `join_us_member`
  ADD PRIMARY KEY (`mbr_sn`),
  ADD UNIQUE KEY `mbr_email` (`mbr_email`);

--
-- Indexes for table `join_us_other`
--
ALTER TABLE `join_us_other`
  ADD PRIMARY KEY (`other_sn`);

--
-- Indexes for table `join_us_student`
--
ALTER TABLE `join_us_student`
  ADD PRIMARY KEY (`std_sn`);

--
-- Indexes for table `reference_id`
--
ALTER TABLE `reference_id`
  ADD PRIMARY KEY (`ri_sn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bd_registration`
--
ALTER TABLE `bd_registration`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `bd_request`
--
ALTER TABLE `bd_request`
  MODIFY `bdr_sn` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `certificate_verification`
--
ALTER TABLE `certificate_verification`
  MODIFY `cv_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cloth_donation`
--
ALTER TABLE `cloth_donation`
  MODIFY `cd_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `creative_view`
--
ALTER TABLE `creative_view`
  MODIFY `sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `education_kit`
--
ALTER TABLE `education_kit`
  MODIFY `ek_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `events_list`
--
ALTER TABLE `events_list`
  MODIFY `ev_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `financial_donation`
--
ALTER TABLE `financial_donation`
  MODIFY `fd_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `join_us_member`
--
ALTER TABLE `join_us_member`
  MODIFY `mbr_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `join_us_other`
--
ALTER TABLE `join_us_other`
  MODIFY `other_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `join_us_student`
--
ALTER TABLE `join_us_student`
  MODIFY `std_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `reference_id`
--
ALTER TABLE `reference_id`
  MODIFY `ri_sn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
