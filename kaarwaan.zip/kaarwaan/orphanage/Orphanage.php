<!DOCTYPE html>
<html lang="en">
<head>

	<title>Kaarwaa.N-Orphanage</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="header.css">
  <link rel="stylesheet" type="text/css" href="Orphanage.css">

	<!--Bootstrap-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

 
</head>

<body>
<?php require('../header.php') ;?>

<!-- Carosel -->
 <div class="about_right_col" style="">
          <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators" >
              <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                  <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner" >
              <div class="carousel-item active orphanage_img_carousel_dimension">
                <img src="img/orph_head_1.jpg" alt="Los Angeles">
                <div class="carousel-caption">
                  <!-- <h3> Orphanage </h3> -->
                  <!-- <p>We had such a great time in Orphanage</p> -->
                </div>   
              </div>

          <div class="carousel-item orphanage_img_carousel_dimension">
            <img src="img/orph_head_2.jpg" alt="Chicago" >
            <div class="carousel-caption">
            <!-- <h3>Orphanage</h3>
            <p>We had such a great time in Orphanage</p> -->
            </div>   
          </div>

          <div class="carousel-item orphanage_img_carousel_dimension">
            <img src="img/orph_head_3.jpg" alt="New York" >
            <div class="carousel-caption">
            <!-- <h3>Orphanage</h3>
            <p>We had such a great time in Orphanage</p> -->
            </div>   
          </div>
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
        </a>
      </div>
</div><br>

<!-- orphanage Content -->

      <div class="container-fluid">
        <div class="container-fluid orphanage_content max-width=">
          <h4 align="center">Orphanage Visit</h4>
        </div>
        <hr style="max-width: 400px;">

<!-- Step taken by Kaarwaa.N  -->

        <div class="container-fluid orphanage_content " align="center">
          <p>
          Kaarwaa.N regularly visits orhanage and organise different activities. Kaarwaa.N don't need any  special occassion to visit to celebrate the day with those young ones with whom life is being unfair. We're the hope for them that life can be interesting full of wonders. Kaarwaa.N share their feeling, sing and dance, perform drama together. Also Kaarwaa.N try to expose them to outer world and encourage. Our small helping hands encourage many lives to find new path out of disgrace.</p>
        </div>
         <br>

<!-- Photos in Card-->

        <div class="card-deck container-fluid cloth_image_container"style="max-width: 1200px;margin: auto;   padding: 16px; border: 2px solid lightgrey;">
<!-- Card 1  -->
          <div class="card" style="max-width:400px">
            <img class="card-img-top" src="img/orph_card_1.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Teaching Session in orhanage.</p>
            </div>
          </div>
<!-- Card 2 -->
           <div class="card" style="max-width:400px">
             <img class="card-img-top" src="img/orph_card_2.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Games Activities at orphanage.</p>
            </div>
          </div>
<!-- Card 3 -->
          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/orph_card_3.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Yoga day celebration and awareness programmes.</p>
            </div> 
          </div>
<!-- Card 4 -->
          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/orph_card_4.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Holi Celebration with kids.</p>
            </div>
          </div>

      </div> 
    <br>
<!-- Scenario -->

<div class=" container-fluid orphanage_success" style="margin: auto;max-width: 1200px;">
  <h3 align="center">Story :-</h3><p align="center"><i>"A child who met his parents"</i></p>
  <div class="row">
    <div class="success_photo col-sm-4" style="max-width: 400px;">
        <img src="img/orph_story.jpg" alt="cloth Photo">
     </div>
    <div class="success_content col-sm-8"><p>This is a story of a child who was lost in this big world full of unknown faces. <br><br>
      On a random visit to orphanage Kaarwaa.N members found him sitting unnoticed in the corner, looking despair. He remained silent for sometime when we try to know the reason behind his sorrow that can be easily noticed from his face. Suddenly he started crying and hugged one of the Kaarwaa.N member and narrate his sorrowful story to us.<br><br> He ran away from his home because of some family issues and somehow orphanage's staff found this boy and bring him here. He has been staying in the orphanage for almost more than a week. Kaarwaa.N team made efforts and tried their best to find his parents. At last, Kaarwaa.N is able to find their contact and reunite this innocent lost child to his family.<br><br>
        <b>Kaarwaa.N always act as a helping hand for needy.</p>
    </div>
 </div>
</div>
<br>

  <!--Footer-->
<?php require('../footer.php') ;?>


<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
  
  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  }

 

</style>
     
 <script>
    
</script>    



</body>
</html>
