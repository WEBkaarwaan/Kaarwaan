<?php
$mbr_name = $mbr_contact = $mbr_pass = $mbr_cpass = $mbr_clg =$mbr_email =$mbr_describe = $mbr_blood =$mbr_branch = "";  
$mbr_otpError = $mbr_passError = $ci_idea  =$rsql = "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Kaarwaa.N-Join as a Member </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" type="text/css" href="join_member.css">

  <!--Bootstrap-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   
</head>

<body>
<?php require('../header.php') ;?>
 <br>
 
   <!-- Member registration(join us)  -->
 

    <div class="container donation_form_container" style="max-width: 800px;">
         <form action="join_member.php" method="POST" enctype="multipart/form-data" >
          <!-- <?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?> -->
            <div class="container-fluid inside_form_container">
                <h3> <strong>Members Regitration</strong> </h3>
                <h6 style="font-size: 12px;"><i>Note:(This registration is only for those who are already active Kaarwaa.N member. If you new please go to <a href="" style="color: blue;">Volunteer Login)</a></i></h6>
                <hr>
                <label for="mbr_name"><b>Name :</b></label>
                <input type="text" name="mbr_name"  placeholder="Enter Full Name" required minlength="5" value="<?php echo $mbr_name;?>"><br>

                <label for="mbr_contact"><b>Contact :</b></label>
                <input type="text" size="10" minlength="10" maxlength="10" required  name="mbr_contact" placeholder="Enter Contact no." value="<?php echo $mbr_contact;?>">

                <label for="mbr_email"><b>Email :</b></label>
                <input type="email" placeholder="Enter Email Id" required minlength="5" name="mbr_email"value="<?php echo $mbr_email;?>" >         


                <label for="mbr_clg"><b>College Name : </b></label>
                <select name="mbr_clg"  value="<?php echo $mbr_clg;?>" required >
                   <option >Jabalpur Engineering College</option>   
                </select>

                   <label for="mbr_branch"><b>Select branch : </b></label>
                <select name="mbr_branch" value="<?php echo $mbr_branch;?>" required>
                    <option >Civil Engineering</option>
                    <option>Computer Science & Engineering</option>
                    <option>Electrical Engineering</option>
                    <option>Electronics & Communication Engineering</option>
                    <option>Industrial and Production Engineering</option>
                    <option>Information Technology Engineering</option>
                    <option>Mechanical Engineering</option>
                </select>

                <label for="mbr_post"><b>Post : </b></label>
                <select name="mbr_post" value="<?php echo $mbr_post;?>" required>
                    <option>Kaarwaa.N Member</option>
                    
                    
                    <option>Project Committee</option>
                    <option>Event Organiser</option>
                    <option>Orphanage Head</option>
                    <option>JNV Co-ordinator</option>
                    <option>School Head</option>
                    <option>Treasurer</option>
                    <option>Media Head</option>
                    <option>Secretary</option>
                    <option>Vice-President</option>
                    <option >President</option>
                    

                </select>


                <label for="mbr_batch"><b>Batch (Passing year)</b></label>
                  <select id="year" name="mbr_batch" value="<?php echo $mbr_batch;?>" ></select>
                    <script type="text/javascript">
                    var start = 2015;
                    var end = new Date().getFullYear() + 4;
                    var options = "";
                    for(var year = start ; year <=end; year++)
                    {
                    options += "<option>"+ year +"</option>";
                    }
                    document.getElementById("year").innerHTML = options;
                    </script>
            



                 <label for="mbr_blood"><b>Blood Group (optional) : </b></label>
                  <!-- go to blood donation page -->
                  <span> <a style="color:blue" href="#" data-toggle="tooltip" title="By providing blood data, you will automatically become a blood donar.Click to know more">Why ?</a></span> 
            <select name="mbr_blood" value="<?php echo $mbr_blood;?>" required>
                    <option >Not Interested</option>
                    <option >A Positive</option>
                    <option>A Negative</option>
                    <option>B Positive</option>
                    <option>B Negative</option>
                    <option>AB Positive</option>
                    <option>AB Negative</option>
                    <option>O Positive</option>
                    <option>O Negative</option>
            </select> 

                
                <label for="mbr_describe" ><b>Describe yourself (optional) : </b></label>
                <textarea name="mbr_describe" required minlength="5" maxlength="40" placeholder="Write Here (below 40 words) " maxlength="40"  value="<?php echo $mbr_describe;?>" >  </textarea>
                
                <input type="hidden" name="MAX_FILE_SIZE" value="1048576" />
                 <label for="mbr_photo"><b>Upload your Photo(<1 MB) :</b></label>
                <input type="file" class="mbr_photo" required name="mbr_photo" MAX accept="image/*" placeholder="Upload only jpg or png">
                <br>

                <span>

                    <label for="mbr_pass"><b>Password :</b></label>
                    <input style="max-width: 300px;" type="password" minlength="5" name="mbr_pass" placeholder="Create New Password">
                <input style="max-width: 300px;" type="password" minlength="5" name="mbr_cpass" placeholder="Confirm Password">
                </span>
                <div class="error"><?php echo  $mbr_passError;?></div>


                  <label for="reference_id"><b>Reference id:</b></label>
                  <input id="active_button" style="max-width: 200px;" onsubmit="open_activate_tab()" type="text" name="reference_id" placeholder="Your unique id">
                    <span><a style="color: blue;" href="#" data-toggle="tooltip" title="For security purpose,only admin have this id. "> Hint ?</a></span>
                     <div class="error"><?php echo  $mbr_otpError;?></div>

                <div class="">
                    
                    <button  type="submit" name="mbr_submit" class="donatebtn" >Submit</button>
                </div>
                
                      
                
                
          </div>
      </form>
</div>
<br>

  <!--Footer-->


<?php require('../footer.php') ;?>






<style>
  
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) { 

  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
  
 

 
}
  @media only screen  and (min-width : 768px) {
    
    
 



}


 .error
{
  color: red;
  font-style: italic;
}

</style>
     
 <script>
   
// jquery script for state select


</script>    



</body>
</html>
  <?php 
if (isset($_SERVER['PHP_SELF'])) {
  # code...



if(isset($_REQUEST['mbr_submit'])){




$uphoto = "";
$mbr_name=$_POST["mbr_name"];
$mbr_email=$_POST["mbr_email"];
$mbr_contact=$_POST["mbr_contact"];
$mbr_pass=$_POST["mbr_pass"];
$mbr_cpass =$_POST["mbr_cpass"];
$mbr_clg =$_POST["mbr_clg"];
$mbr_branch =$_POST["mbr_branch"];
$mbr_branch = $_POST["mbr_batch"];
$mbr_blood =$_POST["mbr_blood"];
$mbr_describe=$_POST["mbr_describe"];


   
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');





    // ******** Upload file *********

  
    // $file_size = "";
    // $file_size = $
    // echo "work Uploadd";
    // echo $file_size;

    if ($file_size > 1048576){      
        $message = 'File too large. File must be less than 1 megabytes.'; 
        echo '<script type="text/javascript">alert("'.$message.'");</script>';
        exit();

    }
  
  $uphoto = $_FILES['mbr_photo']['name'];
  $utmpphoto = $_FILES['mbr_photo']['tmp_name'];
  $uphotofolder = 'mbr_photo/';
  
  $uphoto = $mbr_name."_".$uphoto;





    
    //code to check reference_id---start
$rsql = " SELECT * FROM reference_id ";

$ri_result = $conn->query($rsql);

if ($ri_result->num_rows > 0) {
    // output data of each row
    while($row = $ri_result->fetch_assoc()) {
        $mbr_otp = $row["ri_otp"];

        // echo "id: " . $row["ri_sn"]. " ".$row["ri_otp"]." ";
        break;
    }
} else {
        ?>
        <script type="text/javascript">alert('service unavailable! please try again later. (K321) ')</script>;

        <?php
        exit();
       $mbr_otp = "";
    // echo "OTP service unavailable! please try again later";
}
if ($mbr_otp == $_POST["reference_id"])   {
    //echo "ID matched";

}
else
{
 // echo "ID not matched";
    ?>
        <script type="text/javascript">alert('Wrong Reference ID')</script>;
        <?php
        exit();
  $mbr_otpError = "Wrong Reference ID ";
  
}
if ($_POST["mbr_pass"]==$_POST["mbr_cpass"]) {

 // echo "confrim pass matched";
}
else
{
 // echo "does not macthed "; 
  ?>
  <script type="text/javascript">alert('Password does not match')</script>;
  <?php
      exit();
  // $mbr_passError = "Password doesn't match";

}       //code to check reference_id---end

  
    //code to check if username(email) already registered
      $check_sql = " SELECT * FROM join_us_member ";

$check_result = $conn->query($check_sql);
$check_email = "";

if ($check_result->num_rows > 0) {
    // output data of each row
    while($row = $check_result->fetch_assoc()) {
        $check_email = $row["mbr_email"];
        if ($check_email== $mbr_email) {

          
          ?>
        <script type="text/javascript">alert('Email id already registered')</script>;

        <?php
        exit();

        }
        
        
    }
} else {
        ?>
        <script type="text/javascript">alert('Service unavailable11')</script>;

        <?php
        exit();
       $mbr_otp = "";
    // echo "OTP service unavailable! please try again later";
}


  

if (empty($mbr_passError)) {
  # code...

       $sql = "INSERT INTO join_us_member (mbr_sn, mbr_name, mbr_contact, mbr_email, mbr_clg, mbr_branch, mbr_post, mbr_blood, mbr_describe, mbr_pass, mbr_image, mbr_batch) VALUES (NULL, '".$_POST["mbr_name"]."', '".$_POST["mbr_contact"]."', '".$_POST["mbr_email"]."', '".$_POST["mbr_clg"]."', '".$_POST["mbr_branch"]."', '".$_POST["mbr_post"]."', '".$_POST["mbr_blood"]."', ' ".$_POST["mbr_describe"]."', '".$_POST["mbr_pass"]."', '".$uphoto."','".$_POST["mbr_batch"]."')";

move_uploaded_file($utmpphoto, $uphotofolder.$uphoto);


if ($conn->query($sql) === TRUE) {
    //echo "Your have Registered yourself.";
    ?>
  <script type="text/javascript">alert('You have Registered yourself')</script>;
  <?php
  
    // $submitted = "Your have Registered yourself.";
   

} else {
    // echo "Error: " . $sql . "<br>" . $conn->error;
  //echo "Server Error! please try again later";
       ?>
  <script type="text/javascript">alert('Server Error! please try again later')</script>;
  <?php
      exit();
  // $submitted = "Server Error! please try again later";


}
?>
<!-- <div style="background-color: skyblue;text-align: center;" class="container-fluid"><?php echo $submitted; ?><br></div> -->

<?php
}

}
 
 }
?>    
