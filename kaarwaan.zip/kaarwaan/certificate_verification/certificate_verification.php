
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Certificate Verification </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	
  <link rel="stylesheet" type="text/css" href="certificate_verification.css">

  <!--Bootstrap-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

 
</head>

<body>

<?php require('../header.php') ;?>
<br>
  <div class="container donation_form_container" style="max-width: 450px;">
         <form action="<?php echo htmlspecialchars('certificate_verification.php') ?> " method="Post" >
            <div class="container-fluid inside_form_container">
                <h4><strong>Verify your certificate here</strong></h4>
                <hr>
                
                
                <label><b>Certificate Id:</b></label>
                <input type="text" name="certificate_id"  placeholder="Your reference id" required><br>

                <div class="clearfix">
            
                    <button  type="submit" name="cv_submit" class="donatebtn" >Search</button>
                </div>
          </div>     
      </form>
</div>

<!-- Content -->
 <!-- certificate Form  -->

  <?php  //data fetch from database
 if (isset($_REQUEST["cv_submit"])) {
   # code...
 
  $c_id = $_POST['certificate_id'];

      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');

$sql = "SELECT cv_sn, cv_name, cv_id, cv_issued_date, cv_post FROM certificate_verification 
        WHERE cv_id = '".$c_id."' ";
$result = $conn->query($sql);


if ($conn->query($sql) === TRUE) {
    // echo "New record created successfully";
   
} else {
     // echo "Error: " . $sql . "<br>" . $conn->error;
}
  
?> 
    

  

<br>

<?php 

 if ($result->num_rows >0) {

      $row = $result->fetch_assoc();

?>

<div id="myTable" class="container-fluid" style="width:1200px;">
<table class="table">
  <thead class="table-dark ">
    
    <th>Name</th>
    <th>Certificate Id</th>
    <th>Year Issued</th>
    <th>Post</th>
  </thead>
  <tr style="background-color: lavender">
    <td><?php echo $row["cv_name"]; ?></td>
    <td><?php echo $row["cv_id"]; ?></td>
    <td><?php echo $row["cv_issued_date"]; ?></td>
    <td><?php echo $row["cv_post"]; ?></td>
  </tr>
</table>
</div>

<?php 
}
else
{
?>
    <div align="center" class="container-fluid" style="background-color: tomato;max-width: 1200px;border-radius:28px; ">
          <p>Sorry, No Certificate is registered with this Reference Id. Try with another id.</p>
    </div>
<?php 

}

}


?>
 
<!--Footer-->

<?php require('../footer.php') ;?>

<!-- code for feedback form  -->
<div id="myNav" class="feedback_overlay">

  <!-- Button to close the overlay navigation -->
  <a href="javascript:void(0)" style="z-index: 90;" class="closebtn" onclick="closeNav()">&times;</a>

  <!-- Overlay content -->
  <div class="feedback-content">
<!-- feedback  Form  -->

    <div class="container donation_form_container" style="max-width: 450px;">
         <form action="#" >
            <div class="container-fluid inside_form_container">
                <h3><strong>Feedback to Developers</strong></h3>
                <hr>
                
                
                <label for="user_name"><b>Name :</b></label>
                <input type="text" name="user_name"  placeholder="Your Full Name" ><br>
                 
                <label for="email"><b>Email :</b></label>
                <input type="text" name="email"  placeholder="Your Email" ><br>

                <label for="Your_feedback"><b>Feedback :</b></label>
                <textarea name="Your_feedback"  placeholder="Your Feedback" ></textarea><br>
                

                <div class="clearfix">
            
                    <button  type="submit" class="donatebtn" >Submit</button>
                </div>
          </div>     
      </form>
</div>

<br>
  </div>

</div>



 <!-- Open when someone clicks on the span element  -->
 <script type="text/javascript">
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

/* Close when someone clicks on the "x" symbol inside the overlay */
function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}
</script>


<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
 
  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {

}
	

 

</style>
     
 <script>
    
</script>    



</body>
</html>
