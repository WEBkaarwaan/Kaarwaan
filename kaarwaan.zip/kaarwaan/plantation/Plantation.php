<!DOCTYPE html>
<html lang="en">
<head>

	<title>Kaarwaa.N-Plantation</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="header.css">
  <link rel="stylesheet" type="text/css" href="Plantation.css">

	<!--Bootstrap-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

  
   
</head>

<body>
  <?php require('../header.php') ;?>

<!-- Carosel -->
 <div class="about_right_col" style="">
          <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators" >
              <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                  <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner" >
              <div class="carousel-item active plant_img_carousel_dimension">
                <img src="img/plant_head_1.jpg" alt="Los Angeles">
                <div class="carousel-caption">
                 <!--  <h3> Plantation </h3>
                  <p>We had such a great time in Plantation</p> -->
                </div>   
              </div>

          <div class="carousel-item plant_img_carousel_dimension">
            <img src="img/plant_head_2.jpg" alt="Chicago" >
            <div class="carousel-caption">
          <!--   <h3>Plantation</h3>
            <p>We had such a great time in Plantation</p> -->
            </div>   
          </div>

          <div class="carousel-item plant_img_carousel_dimension">
            <img src="img/plant_head_3.jpg" alt="New York" >
            <div class="carousel-caption">
           <!--  <h3>Plantation</h3>
            <p>We had such a great time in Plantation </p> -->
            </div>   
          </div>
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
        </a>
      </div>
</div><br>

<!-- Plant Content -->

      <div class="container-fluid">
        <div class="container-fluid plant_content max-width=">
          <h4 align="center">Plantation</h4>
          <hr style="max-width: 400px;">
        </div>


<!-- Scenario -->

<div class=" container-fluid plant_success" style="margin: auto;max-width: 1200px;">
  <h3 align="center">Current Scenario :</h3>
  <div class="row">
    <div class="success_photo col-sm-4" style="max-width: 400px;"> <img src="img/plant_on_hand.jpg" alt="cloth Photo"> </div>

    <div class="success_content col-sm-8">According to the World Wide Fund for Nature, we are losing 130,000 square km of forest cover every day. India has been trying to achieve its target of keeping 33 percent of its geographical area under forest cover for decades, but the 2017 State of Forest report shows that it is still struggling to get above 22 percent.
      <br><br>
      Plantation plays an important role in maintaining the balance in nature.We must plant more and more trees and also encourage those around us to do so. It is best to join a nearby NGO working for this cause to work efficiently in this direction.Kaarwaa.N regularly organise awareness programme towards environment and are working towards improving its condition selflessly.

      <br><br>

      
       <b> Goal of Kaarwaa.N is to inspire people to change their attitudes and behaviors toward a more sustainable life.</b>
    </div>
 </div>
</div>
<br>

<!-- Step taken by Kaarwaa.N  -->

        <div class="container-fluid plant_content">
          <h4 align="center">Social Welfare Activities by kaarwaa.N</h4>
          <hr style="max-width: 600px;">
          <p>Plantation of trees started as a foundation in the now called '<b>Kaarwaa.N Garden</b>' in JEC. Campaigns are conducted by Kaarwaa.N to spread awareness about tree plantation and how deforestation is leading to threats like climate change. Other activities involve 'Nukkad Natak' and creative activities like poster making. The plantation is done in association with recognized authorities like Municipal Corporation and Nagar Palika. </p>
        </div><hr style="max-width: 1200px;">

<!-- Photos in Card-->

        <div class="card-deck container-fluid cloth_image_container"style="max-width: 1200px;margin: auto;   padding: 10px; border: 2px solid lightgrey;">
<!-- Card 1  -->
          <div class="card" style="max-width:400px">
            <img class="card-img-top" src="img/plant_card_1.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Plantation at school</p>
            </div>
          </div>
<!-- Card 2 -->
           <div class="card" style="max-width:400px">
             <img class="card-img-top" src="img/plant_card_2.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Plantation at jec college</p>
            </div>
          </div>
<!-- Card 3 -->
          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/plant_card_3.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Plantation at Kaarwaa.N's garden</p>
            </div> 
          </div>
<!-- Card 4 -->
          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/plant_card_4.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Plantaion at Dumna National Park</p>
            </div>
          </div>

      </div> 
    <br>


  <!--Footer-->

<?php require('../footer.php') ;?>


<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
 
  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  }

 

</style>
     
 <script>
    
</script>    



</body>
</html>
