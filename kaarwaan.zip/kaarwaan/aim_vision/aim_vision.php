<!DOCTYPE html>
<html lang="en">
<!--Head-->
<head>

	<title>Kaarwaa.N-Aim and Vision </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	
  <link rel="stylesheet" type="text/css" href="aim_vision.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

  
   
</head>
<!--Body-->
<body>
   <!-- Header Code -->

   <?php require('../header.php') ;?>


<!--nav bar-->

 
<!-- Aim and Vision Content -->

   <!-- Main Content -->
  
   <div class="container-fluid aim_vision_content" >
    <div><h3 align="center">Vision</h3></div>
    <hr style="max-width: 400px;">
     
       <p>
       Kaarwaa.N always tries to work as a catalyst in bringing a change in lives of underpriveleged and poor childrens. We, consistantly working towards another India which is pollution free and and provides healthy enviroment.
       </p>
       
     
   </div><br>

<!-- Card-->

    <div class="card-deck container-fluid  mission_container" style="margin: auto; ">

      <div style="width: 100%;">
        <h3 style="text-align: center;"><strong>Our Mission</strong></h3>
      </div>
         
        <div class="card-deck container-fluid cloth_image_container">

<!-- Card 1  -->
          <div class="card aim_card_color" style="max-width:400px ; background-color:#99b3ff">
            <img class="card-img-top " src="img/LOSA.png" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text"><b>Better Education To Poor Children.</b></p>
            </div>
          </div>
<!-- Card 2 -->
           <div class="card aim_card_color" style="max-width:400px ;background-color:#99b3ff;">
             <img class="card-img-top " src="img/enviroment.png" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text"><b>Awareness Toward Environment.</b></p>
            </div>
          </div>
<!-- Card 3 -->
          <div class="card aim_card_color" style="max-width:400px; background-color:#99b3ff;">
           <img class="card-img-top" src="img/volunteer.png" alt="Card image" style="width:100%">
            <div class="card-body ">
              <p class="card-text"><b>Helping Hand For Orphanage Children.</b></p>
            </div> 
          </div>
<!-- Card 4 -->
          <div class="card aim_card_color" style="max-width:400px; background-color:#99b3ff;">
           <img class="card-img-top" src="img/cleanliness.png" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text"><b>Cleaniless Drive For New India.</b></p>
            </div>
          </div>

      </div> 
    </div>
    <br>


  
<!--Footer-->

<?php require('../footer.php') ;?>

  <style>
  /********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) { 
 
  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
  
 
</style>
     
 <script>
    
</script>    



</body>
</html>

</body>
</html>
