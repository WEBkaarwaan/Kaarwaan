<?php

$MERCHANT_KEY = "TV7kew6B";
$SALT = "ucSr5uMRTx";
// Merchant Key and Salt as provided by Payu.

$PAYU_BASE_URL = "https://sandboxsecure.payu.in";   // For Sandbox Mode (test)
//$PAYU_BASE_URL = "https://secure.payu.in";      // For Production Mode

$action = '';


$posted = array();
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {    
    $posted[$key] = $value; 
  
  }
}
//success and failed url
$posted['surl'] = "http://localhost/donation/donation_financial/success.php";
$posted['furl'] = "http://localhost/donation/donation_financial/failure.php";


$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';
// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
      || empty($posted['service_provider'])
  ) {
    $formError = 1;
    // echo "form error";
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
  $hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';  
  foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
    $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Kaarwaa.N-Donation Financial Help </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" type="text/css" href="donation_financial.css">
  <link href='https://fonts.googleapis.com/css?family=Goblin One' rel='stylesheet'>

  <!--Bootstrap-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  <script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>

  </head>
  <body onload="submitPayuForm()">

<!--        **************header********** -->
<?php require('../header.php') ;?>

 <br>
<div>

<div>
    <div class="container-fluid" style="margin: auto;height: auto;">
      <div class="row">

        <div class="col-sm-5 fdonation_box1 " style="">
          <div class="box1">
            <div class="container-fluid donation_quote" >
                
                <h5 style="" >Your Contribution will transform lives.</h5>
                <img src="img/RTE.jpg" style="width: 100%; max-width: 400px; height: 100%;">
                <ul type="none" style="margin-left:0px; " >
                    <br>
                    <li>Kaarwaa.N has taught more than thousand of children in India, since 2014.</li>
                    <li>Kaarwaa.N has organised more than hundereds of awareness programs.</li>
                    <li>We rely only on donations.</li>
                </ul>
              
                <img src="img/donation_quote1.png" style="width: 100%;">
             </div>                 
             
              </div>   

        </div> 



        <div class="col-sm-7 ">
          <br>
          <div class="row">
          <div class="box2 donation_form_container">

           

        <form action="<?php echo $action; ?>" method="post" name="payuForm">
            <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
            <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
            <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
            <input type="hidden" name="surl" value="<?php echo (empty($posted['surl'])) ? '' : $posted['surl'] ?>" size="64" />
            <input type="hidden" name="furl" value="<?php echo (empty($posted['furl'])) ? '' : $posted['furl'] ?>" size="64" />
            <input type="hidden" name="service_provider" value="payu_paisa" size="64" />


          <div class="container-fluid inside_form_container">
            <h3 style="color:black;text-shadow:2px 1px darkseagreen;"><b>Donation - Financial Help</b></h3>
            <hr>

             <?php if($formError) { ?>
  
          <span style="color:red">Error :Please fill all mandatory fields.</span>
      <br/>
      <br/>
    <?php } ?>


            <label for="firstname"><b>Name :</b></label>
            <input type="text" name="firstname" placeholder="Enter Full Name"  id="firstname" value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>" />

            <!-- <input type="text" name="financial_donar_name"  placeholder="Enter Full Name" required><br> -->

            <label for="phone"><b>phone :</b></label>
            <input type="text" name="phone" placeholder="Enter phone no." value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>" required/>

            <!-- <input type="text"   name="financial_donar_phone" placeholder="Enter phone no." required> -->

            <label for="email"><b>Email :</b></label>
            <input type="text" name="email" placeholder="Enter Email Id" id="email" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>" required />
            <!-- <input type="text" placeholder="Enter Email Id" name="email" required>          -->

            <label>
            <input type="checkbox"  name="remember" style="margin-bottom:5px"><b> Are you Alumini of Jec ?</b>
            </label><br>

            <label for="donation_write"><b>Your Purpose to donate :</b></label>
            <br>
            <textarea name="productinfo" placeholder="Write here..." required><?php echo (empty($posted['productinfo'])) ? '' : $posted['productinfo'] ?></textarea>
            <!-- <textarea name="donation_write" placeholder="Write here..." required></textarea> -->

            <label for="amount"><b>Amount (min-10) : </b></label>
            <input type="number" min="10" placeholder="&#8377" max="100000" maxlength="6" step="10" required name="amount" value="<?php echo (empty($posted['amount'])) ? '' : $posted['amount'] ?>" />

            <!-- <input type="number" id="donation_amount" name="donation_amount"
              min="100" placeholder="&#8377" max="100000" maxlength="6" step="10" required> -->

    <!--<p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>-->

              <div class="clearfix">
      
                  <?php if(!$hash) { ?>
                    <input type="submit" value="Submit" />
          <?php } ?>
              </div>
        </div>
    </form>
    </div>
    </div>
  </div>
   </div>     
  </div>
</div>
<br>

    
   
  <!--   <br/>
    <?php if($formError) { ?>
  
      <span style="color:red">Please fill all mandatory fields.</span>
      <br/>
      <br/>
    <?php } ?>


    <form action="<?php echo $action; ?>" method="post" name="payuForm">
      <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
      <table>
        <tr>
          <td><b>Mandatory Parameters</b></td>
        </tr>
        <tr>
          <td>Amount: </td>
          <td><input name="amount" value="<?php echo (empty($posted['amount'])) ? '' : $posted['amount'] ?>" /></td>
          <td>First Name: </td>
          <td><input name="firstname" id="firstname" value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>" /></td>
        </tr>
        <tr>
          <td>Email: </td>
          <td><input name="email" id="email" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>" /></td>
          <td>Phone: </td>
          <td><input name="phone" value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>" /></td>
        </tr>
        <tr>
          <td>Product Info: </td>
          <td colspan="3"><textarea name="productinfo"><?php echo (empty($posted['productinfo'])) ? '' : $posted['productinfo'] ?></textarea></td>
        </tr>
        <tr>
          <td>Success URI: </td>
          <td colspan="3"><input type="hidden" name="surl" value="<?php echo (empty($posted['surl'])) ? '' : $posted['surl'] ?>" size="64" /></td>
        </tr>
        <tr>
          <td>Failure URI: </td>
          <td colspan="3"><input type="hidden" name="furl" value="<?php echo (empty($posted['furl'])) ? '' : $posted['furl'] ?>" size="64" /></td>
        </tr>

        <tr>
          <td colspan="3"><input type="hidden" name="service_provider" value="payu_paisa" size="64" /></td>
        </tr>

        <tr>
          <td><b>Optional Parameters</b></td>
        </tr>
        <tr>
          <td>Last Name: </td>
          <td><input name="lastname" id="lastname" value="<?php echo (empty($posted['lastname'])) ? '' : $posted['lastname']; ?>" /></td>
          <td>Cancel URI: </td>
          <td><input name="curl" value="" /></td>
        </tr>
        <tr>
          <td>Address1: </td>
          <td><input name="address1" value="<?php echo (empty($posted['address1'])) ? '' : $posted['address1']; ?>" /></td>
          <td>Address2: </td>
          <td><input =name"address2" value="<?php echo (empty($posted['address2'])) ? '' : $posted['address2']; ?>" /></td>
        </tr>
        <tr>
          <td>City: </td>
          <td><input name="city" value="<?php echo (empty($posted['city'])) ? '' : $posted['city']; ?>" /></td>
          <td>State: </td>
          <td><input name="state" value="<?php echo (empty($posted['state'])) ? '' : $posted['state']; ?>" /></td>
        </tr>
        <tr>
          <td>Country: </td>
          <td><input name="country" value="<?php echo (empty($posted['country'])) ? '' : $posted['country']; ?>" /></td>
          <td>Zipcode: </td>
          <td><input name="zipcode" value="<?php echo (empty($posted['zipcode'])) ? '' : $posted['zipcode']; ?>" /></td>
        </tr>
        <tr>
          <td>UDF1: </td>
          <td><input name="udf1" value="<?php echo (empty($posted['udf1'])) ? '' : $posted['udf1']; ?>" /></td>
          <td>UDF2: </td>
          <td><input name="udf2" value="<?php echo (empty($posted['udf2'])) ? '' : $posted['udf2']; ?>" /></td>
        </tr>
        <tr>
          <td>UDF3: </td>
          <td><input name="udf3" value="<?php echo (empty($posted['udf3'])) ? '' : $posted['udf3']; ?>" /></td>
          <td>UDF4: </td>
          <td><input name="udf4" value="<?php echo (empty($posted['udf4'])) ? '' : $posted['udf4']; ?>" /></td>
        </tr>
        <tr>
          <td>UDF5: </td>
          <td><input name="udf5" value="<?php echo (empty($posted['udf5'])) ? '' : $posted['udf5']; ?>" /></td>
          <td>PG: </td>
          <td><input name="pg" value="<?php echo (empty($posted['pg'])) ? '' : $posted['pg']; ?>" /></td>
        </tr>
        <tr>
          <?php if(!$hash) { ?>
            <td colspan="4"><input type="submit" value="Submit" /></td>
          <?php } ?>
        </tr>
      </table>
    </form> -->
  <!--read carefully before donation-->
<div class="container donation_info">
      <h3>Read Carefully :</h3>
      <hr>
      <ol type="1">
          <li>Kaarwaa.N is a non-profitable organisation, please we assured that your given amount will be useful and benefit for the welfare of society.</li>
          <li>You can write your purpose for donation.</li>
          <li>Amount that you will provide will directly send to Kaarwaa.N's account. There is no third person in middle.</li>
          <li>You will get an confirmation sms or email for the payment.</li>
          <li>We also inform every expenses done with your amount.</li>
          <li>You can also personally phone us before donation</li>
          <li>For any query, go to our FAQ section or phone us.</li>
          
      </ul>
 </div>

 
       
  <!--Footer-->


<?php require('../footer.php') ;?>






<style>
  /********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) { 
  
  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
  }
 

</style>
     


    
  </body>
</html>
