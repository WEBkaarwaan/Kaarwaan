<?php

 //with this code Now your PHP compiler will show all error except 'Notice'.
error_reporting (E_ALL ^ E_NOTICE);


// if(!isset($_SERVER['HTTP_REFERER'])){
//     // redirect them to your desired location
//     header("Location: donation_financial.php");
//     exit;
// }


      // this code will prevent direct page access
if (!$status=="failure") {
   # code...
    // redirect them to your desired location
    header("Location: donation_financial.php");
    exit;
 }

$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$phone=$_POST['phone'] ;
$productinfo=$_POST["productinfo"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$email=$_POST["email"];
$salt="ucSr5uMRTx";


// Salt should be same Post Request 

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
         }
		 $hash = hash("sha512", $retHashSeq);
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Kaarwaa.N-Payment Failed </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" type="text/css" href="donation_financial.css">
  <link href='https://fonts.googleapis.com/css?family=Goblin One' rel='stylesheet'>

  <!--Bootstrap-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

 <body>

<?php require('../header.php') ;?>

 <br>
<div>
<div class="container-fluid failed_msg" style="padding:0px;">


<?php

       if ($hash != $posted_hash) {
        ?>
        <div align="center" style="background-color: tomato;border-radius: 4px;"> <h3>Payment Failed!</u></h3></div>

        <?php
         echo "Invalid Transaction. Please try again";
         ?><br>
                   <div class="goback_btn" align="center">
              <button onclick="goback()">Go Back</button>
          </div>
          <br>
          <?php
       } 
else {
    ?>
          <div class="container-fluid" align="center" style="background-color: tomato;border-radius: 4px;"> <h3>Payment Failed!</u></h3></div>
          <div class="container-fluid" align="center" style="padding: 16px;"><h3>We are Sorry, <u> <?php echo $firstname ?> </u>.<br> Your transaction status is <?php echo $status ?>.</h3>
          <h4>Your Reference Id for this transaction is <u> <?php echo $txnid ?>. </u></h4>
          
          <!-- <div align="center" style="background-color: skyblue;max-width: 260px;border-radius: 6px;" class="container-fluid" ><a href="goback.php">Click Here to Go back</a></div> -->
          <div class="goback_btn" align="center">
              <button onclick="goback()">Go Back</button>
          </div>
          <br>
          
         </div>

     <?php     
       }
?>
</div>
<br>
<script>

</script>
 

 <!--Footer-->
<?php require('../footer.php') ;?>


 <!-- send data to database -->
<?php 

  # code...

   
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');
  

$sql = "INSERT INTO `financial_donation` (`fd_sn`, `fd_name`, `fd_contact`, `fd_email`, `fd_description`, `fd_amount`, `fd_reference_id`, `fd_status`) VALUES (NULL, '".$firstname."', '".$phone."', '".$email."', '".$productinfo."', '".$amount."', '".$txnid."', '".$status."');";


if ($conn->query($sql) === TRUE) {
    // echo "Data has been stored";
    

} else {
    // echo "Dats has not been saved, Error!";
       


}


?>



<style>
  /********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) { 
 
  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
  
  }

 

</style>
     

<script>
  function goback() {
  location.href = "donation_financial.php";
}
</script>
    
  </body>
</html>


<!-- 
<?php
if(isset($_REQUEST['submit'])){
$ci_name = $ci_email = $ci_idea  = "";  
    // vairable for connection
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "kaarwaan_db";
//Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";

  // check if Alumini or not
$cheked1 = "NO";

if( empty($_POST["ek_alumini"]) )
 { 
  // echo "not checked";
 $cheked1 = "NO";
  }
else {
  // echo "checked";
  $cheked1= "YES"; 
}
$sql = "INSERT INTO  financial_donation (fd_sn, fd_name, fd_contact, fd_email, fd_alumini, fd_description, fd_amount, fd_transaction, fd_status) VALUES (NULL, '".$_POST["firstname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$cheked1."', '".$_POST["description"]."', '".$_POST['amount']."', '".$_POST['txnid']."', '".$_POST['status']."')";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
   

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


}

?>    
 -->