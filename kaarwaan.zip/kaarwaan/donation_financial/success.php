
<?php

      //with this code Now your PHP compiler will show all error except 'Notice'.
 error_reporting (E_ALL ^ E_NOTICE);


// if(!isset($_SERVER['HTTP_REFERER'])){
//     // redirect them to your desired location
//     header("Location: donation_financial.php");
//     exit;
// }

    //set the index as blank index to remove undefined index error
//$phone = isset($_POST['phone']) ? $_POST['phone'] : '';

$status=$_POST["status"];
$firstname=$_POST["firstname"];
$phone=$_POST['phone'] ;
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];

$salt="ucSr5uMRTx";
echo $phone;
echo $firstname;
echo "working";
echo "string";
echo $status;

if (!$status=="success") {
   # code...
    // redirect them to your desired location
    header("Location: donation_financial.php");
    exit;
 }
// Salt should be same Post Request 

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
         }
     $hash = hash("sha512", $retHashSeq);
       
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Kaarwaa.N-Payment Successful </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" type="text/css" href="donation_financial.css">
  <link href='https://fonts.googleapis.com/css?family=Goblin One' rel='stylesheet'>

  <!--Bootstrap-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

 <body>

 <?php require('../header.php') ;?>
 <br>
<div>
<div class="container-fluid sucess_msg" style="padding:0px;">


<?php
if ($hash != $posted_hash) {
         echo "Invalid Transaction. Please try again";
       } 
else {
    ?>
          <div align="center" style="background-color: green;border-radius: 4px;"> <h3>Payment Successful</u></h3></div>
          <div style="padding: 16px;"><h3>Thank You <u> <?php echo $firstname ?> </u>.<br> Your order status is <?php echo $status ?>.</h3>
          <h4>Your Transaction ID for this transaction is <u> <?php echo $txnid ?>. </u></h4>
          <h4>We have recieved a payment of Rs. <u> <?php echo $amount ?>.</u></h4>
          <!-- <div align="center" style="background-color: skyblue;max-width: 260px;border-radius: 6px;" class="container-fluid" ><a href="goback.php">Click Here to Go back</a></div> -->
          <div class="goback_btn" align="center">
              <button onclick="goback()">Go Back</button>
          </div>
          
         </div>

     <?php     
       }
?>
</div>
<br>
<script>

</script>
 

 <!--Footer-->
<?php require('../footer.php') ;?>



  <!-- send data to database -->
<?php 

  # code...

   
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');

$sql = "INSERT INTO `financial_donation` (`fd_sn`, `fd_name`, `fd_contact`, `fd_email`, `fd_description`, `fd_amount`, `fd_reference_id`, `fd_status`) VALUES (NULL, '".$firstname."', '".$phone."', '".$email."', '".$productinfo."', '".$amount."', '".$txnid."', '".$status."');";


if ($conn->query($sql) === TRUE) {
    // echo "Data has been stored";
    

} else {
    // echo "Data has not been saved, Error!";
       


}


?>
<style>
  /********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) { 

  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
  
}
 

</style>
     

<script>
  function goback() {
  location.href = "donation_financial.php";
}
</script>
    
  </body>
</html>