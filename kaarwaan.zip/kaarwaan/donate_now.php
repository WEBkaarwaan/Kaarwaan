
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kaarwaa.N-A Step For The Welfare Of Another India </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="home.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

    <!--Bootstrap Swiper-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"></script>
   
</head>

<body>


<?php
require("header.php");

?>
	<br>
	<div class="" align="center" style="max-width: 450px;box-shadow: 0px 0px 8px 4px lightgray;margin: auto;border-radius: 30px;">
		
		<div  class="container-fluid donate_now" style="">
			<h4 >Choose option to donate :</h4>	
			<ul type="none">
				<br>
				<u>
				<a href=""><li>Financial Help</li></a>
				<br>
				<a href=""><li>Blood Donation</li></a>
				<br>
				<a href=""><li>Education Kit</li></a>
				<br>
				<a href=""><li>Cloth Education</li></a></u>

			</ul>
		</div>
	</div>
<br>

<?php
require("footer.php");

?>
<style> 

.donate_now
{
  /*box-shadow: 0px 0px 8px 4px lightgray;*/
  max-width: 500px;
  
  padding: 26px;
  height: 400px;
  text-align: center;
  
}
</style>