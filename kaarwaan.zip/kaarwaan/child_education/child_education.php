
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kaarwaa.N-Child Education </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width ,initial-scale=1">
	
  <link rel="stylesheet" type="text/css" href="child_education.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

   
   
</head>

<body>

<?php require('../header.php') ;?>

<!-- Carosel -->
 <div class="about_right_col" style="">
          <div id="demo" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators" >
              <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                  <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner" >
              <div class="carousel-item active child_img_carousel_dimension">
                <img src="img/child_head_1.jpg" alt="Child Education">
                <!-- <div class="carousel-caption">
                  <h3 >Independance Day</h3>
                  <p>Teaching Session</p>
                </div>    -->
              </div>

          <div class="carousel-item child_img_carousel_dimension">
            <img src="img/child_head_2.jpg" alt="Child Education" >
           <!--  <div class="carousel-caption">
            <h3>Independance Day </h3>
            <p>We had such a great time in Plantation</p>
            </div>  -->  
          </div>

          <div class="carousel-item child_img_carousel_dimension">
            <img src="img/child_head_3.jpg" alt="Child Education" >
            <!-- <div class="carousel-caption">
            <h3>Plantation</h3>
            <p>We had such a great time in Plantation</p>
            </div>  -->  
          </div>
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
        </a>
      </div>
</div><br>
      <div class="container-fluid">
        <div class="container-fluid child_content max-width=">

          <h4 align="center">Child Education</h4>
          <hr style="max-width: 400px;">
          <p align="center"><i>“Education is not the filling of a pail, but the lighting of a fire.” ~ William Butler Yeats</i>
        </div>
        <div class="container-fluid child_content">
         <hr style="max-width: 1000px;">
          <p>
            Every year Kaarwaa.N conducts teaching sessions for the preparation of several examinations like Navodaya, Gyanodaya & Samodaya for underpriveleg kids. Kaarwaa.N conduct these sessions in several local schools. This is done to help children enrol in schools with good study programmes, which they could otherwise not get into. The children are provided with study material and stationery from the organizers and the alumini of Kaarwaan.

          </p>
          <hr style="max-width: 1000px;">
          <!-- <ul>
              <li>Every years kaarwaan teach student</li>
              <li>jnv</li>
              <li>graynicja</li>
              <li>we provide matrial</li>
              <li>Prepare them for various exams</li>
              <li>introduce them among current scenerio</li>

          </ul> -->
        </div><br>
        <div class="card-deck container-fluid child_image_container" style="max-width: 1200px;margin: auto ;
          padding: 10px; border: 2px solid lightgrey;">
          <div class="card" style="max-width:400px">
            <img class="card-img-top" src="img/card_img_1.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Teaching sessions for Kids</p>
            </div>
          </div>

           <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/card_img_2.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">School bags distribution</p>
            </div>
          </div>

            
         
          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/card_img_3.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Prize Distribution for their performance</p>
            </div> 
          </div>

          <div class="card" style="max-width:400px">
           <img class="card-img-top" src="img/card_img_4.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
              <p class="card-text">Awaring them about modern technology.</p>
            </div>
          </div>    
      </div> 
    <br>
      <!-- Success Story -->
<div class=" container-fluid child_success" style="margin: auto;max-width: 1200px;">
  <h3 style="text-align: center;"><stong>Success Story</stong></h3>
  <div class="row">
    <div class="success_photo col-sm-4" style="max-width: 400px;"> <img src="img/child_success_stroy.jpg" alt="Child Photo"> </div>
    <div class="success_content col-sm-8"><p style="font-style: italic;">Every child has a dream of Education which can nourish her/him for a bright future but when the dream come true gives a feeling of heartiest satisfaction. <br><br>
Kaarwaa.N has such a story of a child name Roopmati, belongs to a family  of poor background but her will for education is strong enough to defeat such barriers. Her parents always encourage her even they sit for hours during her studies. She selected for Gyanodaya where she can achieve her dream whatever she wants to be. 
<br><br>
<b>"Kaarwaa.N always works for children like Roopmati and their success."</b></p>
</div>
 </div>
</div>
<br> 
<div class=" container-fluid child_success"  style="margin: auto;">
  <h3 align="center">The Story of a chaiwala :</h3>
 
<p><i>For those of you, who begin reading this story with a presumption that at the end of it there will
be a slum dog millionaire, will require more control on their imagination. This story is more
realistic and could well be the story of every middle aged chaiwala selling tea along the streets
of Jabalpur. This particular story is set not very far away but just outside the JEC, Jabalpur.</i>
<br><br>
It is an honour to be involved in the activities of Kaarwaa.N… and presently we are preparing
the fifth standard students of Shaskiya Prathmik Shala, Engineering College, Gokulpur for JNV
examinations. The school is just a few steps from the IP department, JEC, Jabalpur. One fine
morning returning from the classes I sat at a tea stall the owner of which happens to be the
father of Anuj. Anuj is a fourth standard student of the same school. “Bhayya ek chai.”
<br><br>
After a few minutes he hands me the cup of tea and asks me,
<br><br>
“Sir, Anuj ki padhai kaise chal rahe he?”
<br><br>
I reply, “Anuj hoshiyar he bhayya, aap chinta mat karo, hum uske saath mehnat to kar he rahe
he, uski padhai achi chal rahe he.”
<br><br>
“Sir, bas baccho ke liye he sab kuch chal raha he. Wo acchese padh likhkar bade ho jae.”




  <span id="dots">...</span><span id="more">
    <br><br>
    At this moment I can see clearly in his eyes the aspirations of a father to give to his son the life
he himself could not have as a child. Drinking tea alone can be an intriguing experience at
times. Between a few sips of the tea, I recalled the impoverished condition of this chaiwala. The
5m*4m (room+kitchen) house where the family of four stayed, thatched roofs, mud walls, the
torn clothes hanging from the nails on the wall and everything else which was a reminder of his
poor condition and I found myself blurting out inadvertently, “bhayya, didn’t you ever wished to
earn more?”

    <br><br>
    He looked at me, paused as if to judge the real intention of asking that question and then
answered,
    <br><br>
    “Every moment of my life sir, I have wished to earn more money. But when I look around me
and make a few observations I feel no sadness for it. For example, what you are doing for my
children involves a lot of goodness. You are helping my children is one thing and the goodness
in you because of which you are doing this is another thing. I could have bought the first thing
by sending my children to private coaching classes, but how much so ever may I offer you, I will
never be able to buy the goodness involved in you teaching my children and they getting taught
by you….”
 <br><br>
In a few rough words a 10th pass tea vendor summed up the philosophy of self-abnegation and
selflessness without having the slightest hint of it and I realized that life itself is such a great
teacher.
   <br><br>
   “….Sir, the lack of money teaches one more, than the abundance of it. Whatever I do, I do it
for my children Anuj and Shalini. The last time I bought a pair of shoes for myself was in 1992 at
the time of my wedding. They told me that I needed to look good on my marriage and I only
asked, ‘Can’t you get married without shoes?’ Everyone laughed and called me a miser but I
really have never been able to do anything which involves my own self…” <br><br>
I am a strong follower of Swami Vivekananda and his teachings. These words reminded me of a
line I had read somewhere while reading about the great philanthropist ‘Only those who live for
others are truly alive, the rest are more dead.’ <br><br> 

“….they say that happiness and poverty cannot stay under the same roof. It is only partially
true. We have many reasons to be sad about but somehow we double or triple those small
reasons to be happy about. I feel so happy sir, to see how understanding my children are. There
is an ice-cream vendor who would come at times to the shop and if the children would be
around, I would buy ice-creams for them. One day, the vendor came and was calling my
children to come and take the ice-creams but they would not budge which was quite unusual
because usually they would run to the vendor at his very first call and hover around him. Even
when I asked them to go and take the ice-creams they did not. Later, when the vendor left, I
called Anuj and asked, why he didn’t take the ice-cream. With a very serious face and an air of
concern about him he replied, ‘No baba, ma told us that the business is not going very well and
so we should not nag you for things now’. Even now I am in lot of debts because of a series of
illnesses in my family and that day his old T-shirt got torn. His mother stitched it up to sustain
few more months and all he said, ‘Baba, in March next year if you have money we will buy a
new T-shirt, okay a green coloured one. Now because of Shalini’s illness you have had to spend
a lot so please don’t bother buying anything now, ill manage?’ Sir he is just 8 years old and his
understanding leaves me surprised at times...”

<br><br> 
I asked what was it in march?
<br><br> 
“…Oh sir, there is nothing particular. It is just that sometimes I give Anuj rupees 5 and
Shalini 10 rupees which they save, and when they have saved enough or I have some money
we buy clothes for them…” 
<br><br> 
Inadequacy is in itself such a great teacher. A childhood spent in the want of better amenities
can teach you more about fund allocation, priority management and sustainable consumption
then textbooks on the same topics.
<br><br> 
 have food in our house and these instances do make me feel sad. But I like to look at the
brighter side of life and be happy about those things in life infront of which money has no worth
at all…”.
<br><br> 
How do you manage your debts? Don’t your debtors ask you to pay it back?

<br><br> 
“…Oh.. no sir. These debts are on friends. In Bhai Bandhu (comradeship or bonhomie)
everything gets sorted out. Sometimes they help me and when need arises I help them. We are
there for each other. They don’t pressurize me because they know that I will pay them back in
time…”
<br><br> 
I had finished my tea and I got up to pay and leave, but I was in for a surprise
<br><br> 
“…Sir you please don’t pay today. I liked talking to you. People don’t usually care about
what a chaiwala has to say. You gave me a patient listening and on top of that I can never repay
you for what you are doing for my children. Please don’t pay today...”
<br><br> 
I smiled and left.
<br><br> 
That even in the midst of many difficulties this chaiwala is happy is surely something we can
congratulate him on. His selflessness and comradeship is definitely commendable. We may
also take a few lessons from him on tackling depression. But for a conclusion I would like to
draw attention towards the millions in our country struggling to just survive. Such a fundamental
thing as a good education system gets stuck at letters only and never gets transformed in reality
in some schools. Basic infrastructure such as separate toilets for girls and boys, drinking water
facility, playground is missing. I will not take the help of statistics to emphasize on the issue
here. Statistics is not required to view the situation. Often we will see children of school-going
age are picking at dustbins, begging or working as child labour. The number of crimes related
with minors is constantly on the rise. These facts undoubtedly indicate a lacuna (shortcoming) in
the education system of the country. As educated citizens of the country we have certain
responsibilities. When a mere chaiwala talks of such philosophical things as self-abnegation and
selflessness it becomes even more important that educated mass especially the young
generation takes note of it and understand that our responsibilities do not end at casting our
votes in the elections. In fact that is where our responsibilities start. Whether or not the policies
and acts passed in the upper houses are having an effect at the grass root level is something
for the denizens to observe. Such observations may not be of any direct benefit for us but the
feeling of doing well to someone in itself is very fulfilling. There are many children around us
who have witnessed so much difficulties and atrocities in their lives, tales of which can sadden
us to the point of tears. We cannot change the lives of these children in an instant. But what we
can do is make a small effort in that direction as our moral and social obligation. At least try to
build these children a foundation for a better life.

<br><br> 
Story by –
<br><br> 
<b>Mr. Shourav Kumar Deb </b>

  </span></p>
<button onclick="myFunction()" class="readmore_btn" id="myBtn">Read more</button>
  

 </div>
</div>



<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
<br></div>
  <!--Footer-->


<?php require('../footer.php') ;?>


<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
  .footer_div_hide
   {
    display: none;
   } 

  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
  .div_hide {
    display: none;
  }
  .Kaarwaan_logo img
	{	
	width: 100%;
	height: 60px;	
	}  

	.head_main_div
	{
		width: 100%; height: 80px;padding-top: 6px;
	}
 
}
	
  .kaarwaan_navbar
{
  padding-top: 0px;
  padding-bottom: 0px; 


}
#more {display: none;}
 

</style>
     
 <script>
    
</script>    



</body>
</html>
