
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Kaarwaa.N-A Developers </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="developers.css">

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

  
</head>

<body>
<?php require('../header.php') ;?>
<br>

<div class="dev_header" text-align="center">
    <h4>About Developers</h4>
</div>

<hr style="max-width: 600px;">

<br>
  <!-- Information -->
<div class="container-fluid " align="center" style="max-width: 400px;">
  <div class="card-deck">

  <div class="card dev_card" align="center">
    <div align="center"><img class="card-img-top" src="img/saurabh_kaarwaan21.jpg" alt="Card image cap"> </div>
    <div class="card-body dev_card_body" style="padding: 6px;">
      <h5 class="card-title">Saurabh Chaurasia</h5>
      <p class="card-text">CSE'21 (JEC)</p>
    </div>
    <div class="card-footer" style="padding: 6px;">
      <small class="text-muted">Contact :<br> about.srb@gmail.com</small>
    </div>
  </div>

 <div class="card dev_card" align="center">
    <div align="center"><img class="card-img-top" src="img/keshav_kaarwaan21.jpg" alt="Card image cap"> </div>
    <div class="card-body dev_card_body" style="padding: 6px;">
      <h5 class="card-title">Keshav parihar</h5>
      <p class="card-text">IT'21 (JEC)</p>
    </div>
    <div class="card-footer" style="padding: 6px;">
      <small class="text-muted">Contact : <br> justparihar04@gmail.com</small>
    </div>
  </div>
 

</div>

</div>

<br><div class="container-fluid" align="center"><i>This website is designed and developed with no cost paid, anyone who is interested can contribute to this website. For further detail contact developers. </i></div>
<br>
  <!--Footer-->


<?php require('../footer.php') ;?>






<style>
	
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
 
  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
 
 
}
	@media only screen  and (min-width : 768px) {
		
		
 


.swiper-slide-active
    {
    margin: 0px 0px 0px 0px 0px ;
    }
    
}


 

</style>
     
 <script>
        /* sSlider*/
     var swiper = new Swiper('.swiper-container', {
      slidesPerView: 4,
      spaceBetween: 10,
      // init: false,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      breakpoints: {
        1024: {
          slidesPerView: 4,
          spaceBetween: 40,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 30,
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        320: {
          slidesPerView: 1,
          spaceBetween: 10,
        }
      }
    });
</script>    



</body>
</html>
