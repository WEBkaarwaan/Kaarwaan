
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Donation - Cloth Donation </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="cloth_donation.css">
  <link href='https://fonts.googleapis.com/css?family=Goblin One' rel='stylesheet'>

	<!--Bootstrap-->
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    

  
   
</head>

<body>
<?php require('../header.php') ;?>
 <br>
 <div>
    <div class="container-fluid" style="margin: auto;height:100%;">
      <div class="row">

        <div class="col-sm-5 fdonation_box1 " style="">
          <div class="box1">
            <div class="container-fluid donation_quote" >
                
                <h4><b>Your Contribution will transform lives.</b></h4>
                <img  src="img/cloth.jpg" style="width: 100%; max-width: 500px; height: 100%;"><br><br>
                <ul type="none" style="margin-left:0px; " >
                    
                    <li>Kaarwaa.N regularly organise cloth distribution programmes.</li>
                    <li>kaarwaa.N has helped more than thousands of needy.</li>
                    
                </ul>
              <img  src="img/ab.jpg" style="width: 100%; max-width: 500px; height: 100%;">
                
             </div>                 
             
              </div>   

        </div> 
  


 <div class="col-sm-7 ">
<div class="container-fluid donation_form_container" style="width: 100%;">
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" >
          <div class="container-fluid inside_form_container">
            <h3 style="color:black;text-shadow:2px 1px darkseagreen;"><b>Cloth Donation</b></h3>
            <hr>
            <label for="cd_name"><b>Your Name :</b></label>
            <input type="text" name="cd_name"  placeholder="Enter Full Name" required><br>

            <label for="cd_contact"><b>Contact :</b></label>
            <input type="text"   name="cd_contact" placeholder="Enter Contact no." required>

            <label for="cd_email"><b>Email :</b></label>
            <input type="text" placeholder="Enter Email Id" name="cd_email" >         

            <label for="cd_type"><b>Cloth type : </b></label>
            <select name="cd_type">
              
                <option>Old Cloth</option>
                <option>New cloth</option>  
            </select>

            <label>
            <input type="checkbox"  name="cd_alumini" style="margin-bottom:5px"><b> Are you Alumini of Jec ?</b>
            </label><br>

            <label for="cd_write"><b>How will you send us the clothes :</b></label>
            <br>
            <textarea name="cd_write" placeholder="Write here..." required></textarea>

            

    <p>After submiting, we will process your request and try to contact you for further process.</p>

    <div class="clearfix">
      
    <button type="submit" name="cd_submit" class="donatebtn" >Submit</button>
    </div>
  </div>
</form>
</div>        
</div>


 <div class="container-fluid donation_quote">
  <br>
    <p style="font-style: italic;color: red;">“You have not lived today until you have done something for someone who can never repay you." -John Bunyan</p>
 </div>   
       
  <!--Footer-->



<?php require('../footer.php') ;?>




<style>
	/********************************/
/*          Media Queries       */
/********************************/
  /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) {	
  
  }
	
	/*media query if screen size less than 768*/
	@media only screen and (max-width: 768px) {
  
 
}
	

 

</style>
     
 <script>
    
</script>    



</body>
</html>


<?php  //form for registration


if(isset($_REQUEST['cd_submit'])){
$ci_name = $ci_email = $ci_idea  = "";  
    
      // **********Connect database******

  require($_SERVER['DOCUMENT_ROOT'].'/connect_db.php');

  // check if Alumini or not
$cheked1 = "NO";

if( empty($_POST["cd_alumini"]) )
 { 
  // echo "not checked";
 $cheked1 = "NO";
  }
else {
  // echo "checked";
  $cheked1= "YES"; 
}





$sql = "INSERT INTO cloth_donation (cd_sn, cd_name, cd_contact, cd_email, cd_type, cd_alumini, cd_write) VALUES (NULL, '".$_POST["cd_name"]."', '".$_POST["cd_contact"]."', '".$_POST["cd_email"]."', '".$_POST["cd_type"]."',  '".$cheked1."', '".$_POST["cd_write"]."')";


if ($conn->query($sql) === TRUE) {
    // echo "New record created successfully";
     ?>
     <script type="text/javascript">alert('You have registered successfully');</script>
     <script type="text/javascript">location.href = "cloth_donation.php";</script>
  <?php
   

} else {
    // echo "Error: " . $sql . "<br>" . $conn->error;
    ?>
     <script type="text/javascript">alert('Error! );</script>
     <script type="text/javascript">location.href = "cloth_donation.php";</script>
  <?php
}


}

?>  